# Angular Conceptos - Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Transformar el movie-manager Angular 19 en un showcase educativo con secciones por concepto: componentes, módulos, directivas, servicios, navegación, signals vs observables, estado, y Angular Material.

**Architecture:** App Angular 19 standalone. Rutas bajo `/conceptos/*` para cada sección didáctica. Las películas reales siguen en `/movies`. Home page con grid de tarjetas como menú de conceptos.

**UI Strategy:**
- **Navbar + Home**: Angular Material (MatToolbar, MatCard) — muestra que existe como biblioteca Angular
- **Sección /material**: Showcase detallado de componentes Material
- **Todas las demás secciones**: Bootstrap 5 via CDN + HTML semántico + Angular puro — el alumno ve la estructura Angular sin ruido de componentes externos
- Los tabs en secciones de conceptos se implementan con Angular puro (signal + class binding), no con MatTabGroup ni Bootstrap JS — es más didáctico

**Tech Stack:** Angular 19, Angular Material 19 (solo navbar/home/material-section), Bootstrap 5 CDN, TypeScript, RxJS, TMDB API con fallback mock.

---

## File Map

**Modificar:**
- `movie-manager/src/index.html` — agregar Bootstrap CDN
- `movie-manager/src/styles.css` — tema Material + estilos globales
- `movie-manager/src/app/app.config.ts` — agregar `provideAnimationsAsync()`
- `movie-manager/src/app/app.routes.ts` — agregar rutas conceptos
- `movie-manager/src/app/features/movies/models/movie.model.ts` — agregar `vote_average`
- `movie-manager/src/app/features/movies/services/movie.service.ts` — mock fallback + `searchMovies()`
- `movie-manager/src/app/features/auth/services/auth.service.ts` — convertir a signal
- `movie-manager/src/app/core/guards/auth.guard.ts` — usar signal
- `movie-manager/src/app/features/home/components/home.component.{ts,html,css}` — rediseño landing con Material
- `movie-manager/src/app/shared/components/navbar/navbar.component.{ts,html,css}` — Material toolbar

**Crear:**
- `movie-manager/src/app/features/conceptos/componentes/componentes-page.component.{ts,html,css}`
- `movie-manager/src/app/features/conceptos/componentes/movie-card-demo/movie-card-demo.component.{ts,html,css}`
- `movie-manager/src/app/features/conceptos/modulos/modulos-page.component.{ts,html,css}`
- `movie-manager/src/app/features/conceptos/directivas/directivas-page.component.{ts,html,css}`
- `movie-manager/src/app/features/conceptos/directivas/highlight.directive.ts`
- `movie-manager/src/app/features/conceptos/directivas/if-logged.directive.ts`
- `movie-manager/src/app/features/conceptos/servicios/servicios-page.component.{ts,html,css}`
- `movie-manager/src/app/features/conceptos/navegacion/navegacion-page.component.{ts,html,css}`
- `movie-manager/src/app/features/conceptos/signals-observables/signals-observables-page.component.{ts,html,css}`
- `movie-manager/src/app/features/conceptos/estado/estado-page.component.{ts,html,css}`
- `movie-manager/src/app/features/conceptos/material/material-page.component.{ts,html,css}`

---

## Task 1: Setup — Material + Bootstrap + Config

**Files:**
- Modify: `movie-manager/src/index.html`
- Modify: `movie-manager/src/styles.css`
- Modify: `movie-manager/src/app/app.config.ts`
- Run: `npm install` in `movie-manager/`

- [ ] **Step 1: Instalar Angular Material y CDK**

```bash
cd /Users/lumpierrez/Downloads/ejemplos-de-clase-6-Angular-Advanced/movie-manager && npm install @angular/material @angular/cdk
```

- [ ] **Step 2: Agregar Bootstrap CDN a index.html**

```html
<!-- movie-manager/src/index.html -->
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Angular Conceptos</title>
  <base href="/">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="favicon.ico">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/@angular/material/prebuilt-themes/azure-blue.css" rel="stylesheet">
</head>
<body class="mat-typography">
  <app-root></app-root>
</body>
</html>
```

- [ ] **Step 3: Actualizar styles.css**

```css
/* movie-manager/src/styles.css */
* { box-sizing: border-box; }
body { margin: 0; font-family: Roboto, sans-serif; background: #f5f5f5; }
.spacer { flex: 1 1 auto; }

/* Utilidades compartidas entre secciones de conceptos */
.concepto-page { max-width: 900px; margin: 0 auto; padding: 24px 16px; }
.back-link { color: #3f51b5; text-decoration: none; font-size: 0.9rem; display: inline-block; margin-bottom: 12px; }
.back-link:hover { text-decoration: underline; }
.page-title { color: #1a237e; margin: 0 0 4px; }
.page-subtitle { color: #666; margin-bottom: 24px; }
.info-box { background: #e8eaf6; border-left: 4px solid #3f51b5; padding: 12px 16px; border-radius: 4px; margin-bottom: 20px; }
.info-box p { margin: 4px 0; }
.code-block { background: #1e1e1e; color: #d4d4d4; padding: 16px; border-radius: 8px; font-size: 0.82rem; overflow-x: auto; white-space: pre; line-height: 1.5; font-family: 'Courier New', monospace; margin: 12px 0; }
.demo-box { background: white; border: 1px solid #e0e0e0; border-radius: 8px; padding: 20px; margin-top: 16px; }
.tab-nav { display: flex; gap: 4px; border-bottom: 2px solid #e0e0e0; margin-bottom: 20px; flex-wrap: wrap; }
.tab-btn { background: none; border: none; padding: 10px 18px; cursor: pointer; border-radius: 4px 4px 0 0; color: #666; font-size: 0.95rem; transition: all 0.15s; }
.tab-btn:hover { background: #f0f0f0; color: #333; }
.tab-btn.active { color: #3f51b5; border-bottom: 2px solid #3f51b5; margin-bottom: -2px; font-weight: 500; }
```

- [ ] **Step 4: Actualizar app.config.ts**

```ts
// movie-manager/src/app/app.config.ts
import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

import { routes } from './app.routes';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideHttpClient(),
    provideAnimationsAsync(),
  ],
};
```

- [ ] **Step 5: Verificar compilación**

```bash
cd /Users/lumpierrez/Downloads/ejemplos-de-clase-6-Angular-Advanced/movie-manager && npx ng build --configuration development 2>&1 | tail -10
```
Expected: Build exitoso sin errores.

---

## Task 2: Actualizar Movie model y MovieService

**Files:**
- Modify: `movie-manager/src/app/features/movies/models/movie.model.ts`
- Modify: `movie-manager/src/app/features/movies/services/movie.service.ts`

- [ ] **Step 1: Agregar vote_average al modelo**

```ts
// movie-manager/src/app/features/movies/models/movie.model.ts
export interface Movie {
  id: number;
  title: string;
  overview: string;
  original_language: string;
  poster_path: string;
  release_date: string;
  vote_average?: number;
}
```

- [ ] **Step 2: Reemplazar movie.service.ts completo**

```ts
// movie-manager/src/app/features/movies/services/movie.service.ts
import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Movie } from '../models/movie.model';

@Injectable({ providedIn: 'root' })
export class MovieService {
  private apiUrl = 'https://api.themoviedb.org/3';
  private apiKey = '36eb10aa56ea823b1b3c7370a05aeb09';
  private imageBaseUrl = 'https://image.tmdb.org/t/p/w500';

  private readonly MOCK_MOVIES: Movie[] = [
    { id: 1, title: 'Inception', overview: 'Un ladrón que roba secretos a través del sueño del objetivo.', original_language: 'en', poster_path: 'assets/no-poster.png', release_date: '2010-07-16', vote_average: 8.8 },
    { id: 2, title: 'The Dark Knight', overview: 'Batman enfrenta al Joker en Gotham City en una batalla épica.', original_language: 'en', poster_path: 'assets/no-poster.png', release_date: '2008-07-18', vote_average: 9.0 },
    { id: 3, title: 'Interstellar', overview: 'Un equipo de exploradores viaja a través de un agujero de gusano en busca de un nuevo hogar.', original_language: 'en', poster_path: 'assets/no-poster.png', release_date: '2014-11-07', vote_average: 8.6 },
    { id: 4, title: 'El Señor de los Anillos', overview: 'Un hobbit emprende una aventura épica para destruir un anillo de poder.', original_language: 'en', poster_path: 'assets/no-poster.png', release_date: '2001-12-19', vote_average: 8.9 },
    { id: 5, title: 'Matrix', overview: 'Un hacker descubre que la realidad que conoce es una simulación.', original_language: 'en', poster_path: 'assets/no-poster.png', release_date: '1999-03-31', vote_average: 8.7 },
    { id: 6, title: 'Pulp Fiction', overview: 'Historias entrelazadas del crimen en Los Ángeles contadas de forma no lineal.', original_language: 'en', poster_path: 'assets/no-poster.png', release_date: '1994-10-14', vote_average: 8.9 },
  ];

  movies = signal<Movie[]>([]);
  isLoading = signal(false);
  error = signal<string | null>(null);

  constructor(private http: HttpClient) {}

  loadPopularMovies(page: number = 1) {
    this.isLoading.set(true);
    this.error.set(null);

    const params = new HttpParams()
      .set('api_key', this.apiKey)
      .set('language', 'en-US')
      .set('page', page.toString());

    this.http
      .get<{ results: Movie[] }>(`${this.apiUrl}/movie/popular`, { params })
      .subscribe({
        next: (response) => {
          this.movies.set(response.results.map(m => ({
            ...m,
            poster_path: m.poster_path ? `${this.imageBaseUrl}${m.poster_path}` : 'assets/no-poster.png',
          })));
          this.isLoading.set(false);
        },
        error: () => {
          this.movies.set(this.MOCK_MOVIES);
          this.isLoading.set(false);
        },
      });
  }

  searchMovies(query: string): Observable<Movie[]> {
    if (!query.trim()) return of([]);

    const params = new HttpParams()
      .set('api_key', this.apiKey)
      .set('query', query)
      .set('language', 'en-US');

    return this.http
      .get<{ results: Movie[] }>(`${this.apiUrl}/search/movie`, { params })
      .pipe(
        map(r => r.results.map(m => ({
          ...m,
          poster_path: m.poster_path ? `${this.imageBaseUrl}${m.poster_path}` : 'assets/no-poster.png',
        }))),
        catchError(() => of(
          this.MOCK_MOVIES.filter(m => m.title.toLowerCase().includes(query.toLowerCase()))
        ))
      );
  }

  getMockMovies(): Movie[] {
    return this.MOCK_MOVIES;
  }
}
```

---

## Task 3: Actualizar AuthService con signals

**Files:**
- Modify: `movie-manager/src/app/features/auth/services/auth.service.ts`
- Modify: `movie-manager/src/app/core/guards/auth.guard.ts`

- [ ] **Step 1: Reemplazar auth.service.ts**

```ts
// movie-manager/src/app/features/auth/services/auth.service.ts
import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {
  // ============================================================
  // VERSIÓN ANTIGUA (sin reactividad):
  // private isLoggedBool = false;
  // public isUserLogged(): boolean { return this.isLoggedBool; }
  //
  // Problema: el Navbar no detecta el cambio automáticamente.
  // Hay que consultar el valor en cada ciclo de detección.
  // ============================================================

  // VERSIÓN CON SIGNAL: el cambio se propaga automáticamente
  isLogged = signal(false);

  public login(email: string, password: string): boolean {
    if (email === 'user' && password === '1234') {
      this.isLogged.set(true);
      localStorage.setItem('token', 'token-back');
      return true;
    }
    alert('Credenciales inválidas');
    return false;
  }

  public logout(): void {
    this.isLogged.set(false);
    localStorage.removeItem('token');
  }

  public isUserLogged(): boolean {
    return this.isLogged();
  }
}
```

- [ ] **Step 2: Actualizar auth.guard.ts**

```ts
// movie-manager/src/app/core/guards/auth.guard.ts
import { CanActivateFn } from '@angular/router';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../features/auth/services/auth.service';

export const authGuard: CanActivateFn = () => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (authService.isLogged()) {
    return true;
  }
  router.navigate(['/login']);
  return false;
};
```

---

## Task 4: Actualizar rutas

**Files:**
- Modify: `movie-manager/src/app/app.routes.ts`

- [ ] **Step 1: Reemplazar app.routes.ts**

```ts
// movie-manager/src/app/app.routes.ts
import { Routes } from '@angular/router';
import { MoviesPageComponent } from './features/movies/pages/movies-page/movies-page.component';
import { HomeComponent } from './features/home/components/home.component';
import { NotFoundComponent } from './shared/components/not-found/not-found.component';
import { LoginComponent } from './features/auth/components/login/login.component';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'movies', component: MoviesPageComponent, canActivate: [authGuard] },
  { path: 'login', component: LoginComponent },
  {
    path: 'conceptos/componentes',
    loadComponent: () => import('./features/conceptos/componentes/componentes-page.component').then(m => m.ComponentesPageComponent),
  },
  {
    path: 'conceptos/modulos',
    loadComponent: () => import('./features/conceptos/modulos/modulos-page.component').then(m => m.ModulosPageComponent),
  },
  {
    path: 'conceptos/directivas',
    loadComponent: () => import('./features/conceptos/directivas/directivas-page.component').then(m => m.DirectivasPageComponent),
  },
  {
    path: 'conceptos/servicios',
    loadComponent: () => import('./features/conceptos/servicios/servicios-page.component').then(m => m.ServiciosPageComponent),
  },
  {
    path: 'conceptos/navegacion',
    loadComponent: () => import('./features/conceptos/navegacion/navegacion-page.component').then(m => m.NavegacionPageComponent),
  },
  {
    path: 'conceptos/signals-observables',
    loadComponent: () => import('./features/conceptos/signals-observables/signals-observables-page.component').then(m => m.SignalsObservablesPageComponent),
  },
  {
    path: 'conceptos/estado',
    loadComponent: () => import('./features/conceptos/estado/estado-page.component').then(m => m.EstadoPageComponent),
  },
  {
    path: 'conceptos/material',
    loadComponent: () => import('./features/conceptos/material/material-page.component').then(m => m.MaterialPageComponent),
  },
  { path: '**', component: NotFoundComponent },
];
```

---

## Task 5: Rediseñar Home page (Angular Material)

**Files:**
- Modify: `movie-manager/src/app/features/home/components/home.component.ts`
- Modify: `movie-manager/src/app/features/home/components/home.component.html`
- Modify: `movie-manager/src/app/features/home/components/home.component.css`

- [ ] **Step 1: Actualizar home.component.ts**

```ts
// movie-manager/src/app/features/home/components/home.component.ts
import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

interface ConceptCard {
  titulo: string;
  descripcion: string;
  ruta: string;
  icono: string;
  color: string;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterModule, MatCardModule, MatButtonModule, MatIconModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent {
  conceptos: ConceptCard[] = [
    { titulo: 'Componentes', descripcion: '@Input, @Output, two-way binding y lifecycle hooks.', ruta: '/conceptos/componentes', icono: 'widgets', color: '#3f51b5' },
    { titulo: 'Módulos vs Standalone', descripcion: 'NgModule clásico vs componentes standalone de Angular 19.', ruta: '/conceptos/modulos', icono: 'view_module', color: '#9c27b0' },
    { titulo: 'Directivas', descripcion: 'Built-in (ngFor, ngSwitch) y directivas personalizadas de atributo y estructurales.', ruta: '/conceptos/directivas', icono: 'tune', color: '#e91e63' },
    { titulo: 'Servicios', descripcion: 'Inyección de dependencias, providedIn root y comunicación entre componentes.', ruta: '/conceptos/servicios', icono: 'miscellaneous_services', color: '#ff5722' },
    { titulo: 'Navegación', descripcion: 'Routing, parámetros de ruta, lazy loading y guardas de acceso.', ruta: '/conceptos/navegacion', icono: 'route', color: '#009688' },
    { titulo: 'Signals vs Observables', descripcion: 'Cuándo usar cada uno y cómo se complementan en una búsqueda real.', ruta: '/conceptos/signals-observables', icono: 'compare_arrows', color: '#ff9800' },
    { titulo: 'Estado', descripcion: 'Estado reactivo global con signals: el problema del booleano y la solución.', ruta: '/conceptos/estado', icono: 'memory', color: '#607d8b' },
    { titulo: 'Angular Material', descripcion: 'Biblioteca de componentes UI que siguen Material Design de Google.', ruta: '/conceptos/material', icono: 'palette', color: '#795548' },
  ];
}
```

- [ ] **Step 2: Actualizar home.component.html**

```html
<!-- movie-manager/src/app/features/home/components/home.component.html -->
<div class="home-container">
  <div class="home-header">
    <h1>Angular Conceptos</h1>
    <p>Seleccioná un tema para explorar ejemplos interactivos</p>
  </div>

  <div class="conceptos-grid">
    @for (concepto of conceptos; track concepto.ruta) {
      <mat-card class="concepto-card" [routerLink]="concepto.ruta">
        <mat-card-header>
          <div class="card-icon" [style.background]="concepto.color" mat-card-avatar>
            <mat-icon>{{ concepto.icono }}</mat-icon>
          </div>
          <mat-card-title>{{ concepto.titulo }}</mat-card-title>
        </mat-card-header>
        <mat-card-content>
          <p>{{ concepto.descripcion }}</p>
        </mat-card-content>
        <mat-card-actions>
          <button mat-button [style.color]="concepto.color">Ver ejemplos →</button>
        </mat-card-actions>
      </mat-card>
    }
  </div>
</div>
```

- [ ] **Step 3: Actualizar home.component.css**

```css
/* movie-manager/src/app/features/home/components/home.component.css */
.home-container { max-width: 1100px; margin: 0 auto; padding: 32px 16px; }
.home-header { text-align: center; margin-bottom: 40px; }
.home-header h1 { font-size: 2.5rem; margin: 0 0 8px; color: #1a237e; }
.home-header p { color: #666; font-size: 1.1rem; }
.conceptos-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; }
.concepto-card { cursor: pointer; transition: transform 0.2s, box-shadow 0.2s; }
.concepto-card:hover { transform: translateY(-4px); box-shadow: 0 8px 24px rgba(0,0,0,0.15); }
.card-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; }
.card-icon mat-icon { color: white; }
mat-card-content p { color: #555; line-height: 1.5; margin: 12px 0 4px; }
```

---

## Task 6: Actualizar Navbar con Angular Material

**Files:**
- Modify: `movie-manager/src/app/shared/components/navbar/navbar.component.ts`
- Modify: `movie-manager/src/app/shared/components/navbar/navbar.component.html`
- Modify: `movie-manager/src/app/shared/components/navbar/navbar.component.css`

- [ ] **Step 1: Actualizar navbar.component.ts**

```ts
// movie-manager/src/app/shared/components/navbar/navbar.component.ts
import { Component, inject } from '@angular/core';
import { RouterModule, Router } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { AuthService } from '../../../features/auth/services/auth.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterModule, MatToolbarModule, MatButtonModule, MatIconModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css',
})
export class NavbarComponent {
  authService = inject(AuthService);
  private router = inject(Router);

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
```

- [ ] **Step 2: Actualizar navbar.component.html**

```html
<!-- movie-manager/src/app/shared/components/navbar/navbar.component.html -->
<mat-toolbar color="primary">
  <a routerLink="/" class="brand">
    <mat-icon>movie</mat-icon>
    Angular Conceptos
  </a>
  <span class="spacer"></span>
  <a mat-button routerLink="/">Inicio</a>
  <a mat-button routerLink="/movies">Películas</a>
  @if (authService.isLogged()) {
    <button mat-button (click)="logout()">
      <mat-icon>logout</mat-icon> Cerrar sesión
    </button>
  } @else {
    <a mat-button routerLink="/login">
      <mat-icon>login</mat-icon> Iniciar sesión
    </a>
  }
</mat-toolbar>
```

- [ ] **Step 3: Actualizar navbar.component.css**

```css
/* movie-manager/src/app/shared/components/navbar/navbar.component.css */
.brand { display: flex; align-items: center; gap: 8px; color: white; text-decoration: none; font-size: 1.1rem; font-weight: 500; }
.brand mat-icon { font-size: 1.4rem; height: 1.4rem; width: 1.4rem; }
```

---

## Task 7: Sección Componentes (Bootstrap + Angular puro)

**Files:**
- Create: `movie-manager/src/app/features/conceptos/componentes/componentes-page.component.{ts,html,css}`
- Create: `movie-manager/src/app/features/conceptos/componentes/movie-card-demo/movie-card-demo.component.{ts,html,css}`

- [ ] **Step 1: Crear MovieCardDemoComponent**

```ts
// movie-manager/src/app/features/conceptos/componentes/movie-card-demo/movie-card-demo.component.ts
import { Component, Input, Output, EventEmitter, OnInit, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import { UpperCasePipe } from '@angular/common';
import { Movie } from '../../../../features/movies/models/movie.model';

@Component({
  selector: 'app-movie-card-demo',
  standalone: true,
  imports: [UpperCasePipe],
  templateUrl: './movie-card-demo.component.html',
  styleUrl: './movie-card-demo.component.css',
})
export class MovieCardDemoComponent implements OnInit, OnChanges, OnDestroy {
  // @Input: el padre le pasa datos al hijo
  @Input({ required: true }) movie!: Movie;
  @Input() destacada: boolean = false;

  // @Output: el hijo emite eventos hacia el padre
  @Output() seleccionada = new EventEmitter<Movie>();
  @Output() agregadaFavoritos = new EventEmitter<Movie>();

  esFavorita = false;

  // Lifecycle: se ejecuta una vez al crear el componente
  ngOnInit() {
    console.log(`[ngOnInit] MovieCardDemo "${this.movie.title}" creado`);
  }

  // Lifecycle: se ejecuta cada vez que cambia un @Input
  ngOnChanges(changes: SimpleChanges) {
    if (changes['movie']) {
      console.log(`[ngOnChanges] Película cambió a: "${this.movie.title}"`);
    }
  }

  // Lifecycle: se ejecuta al destruir el componente
  ngOnDestroy() {
    console.log(`[ngOnDestroy] MovieCardDemo "${this.movie.title}" destruido`);
  }

  seleccionar() {
    this.seleccionada.emit(this.movie);
  }

  toggleFavorito() {
    this.esFavorita = !this.esFavorita;
    if (this.esFavorita) this.agregadaFavoritos.emit(this.movie);
  }
}
```

```html
<!-- movie-card-demo.component.html -->
<div class="card" [class.border-warning]="destacada" [class.border-2]="destacada">
  <div class="card-body">
    <h5 class="card-title">{{ movie.title }}</h5>
    <h6 class="card-subtitle mb-2 text-muted">
      {{ movie.release_date }} · {{ movie.original_language | uppercase }}
    </h6>
    <p class="card-text">{{ movie.overview }}</p>
    <div class="d-flex gap-2 mb-2">
      @if (destacada) {
        <span class="badge bg-warning text-dark">⭐ Destacada</span>
      }
      @if (esFavorita) {
        <span class="badge bg-danger">❤️ Favorita</span>
      }
    </div>
    <div class="d-flex gap-2">
      <button class="btn btn-primary btn-sm" (click)="seleccionar()">Seleccionar</button>
      <button class="btn btn-outline-danger btn-sm" (click)="toggleFavorito()">
        {{ esFavorita ? '❤️ Quitar' : '🤍 Favorito' }}
      </button>
    </div>
  </div>
</div>
```

```css
/* movie-card-demo.component.css */
.card { transition: box-shadow 0.2s; }
.card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
```

- [ ] **Step 2: Crear ComponentesPageComponent**

```ts
// movie-manager/src/app/features/conceptos/componentes/componentes-page.component.ts
import { Component, signal, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MovieCardDemoComponent } from './movie-card-demo/movie-card-demo.component';
import { MovieService } from '../../movies/services/movie.service';
import { Movie } from '../../movies/models/movie.model';

@Component({
  selector: 'app-componentes-page',
  standalone: true,
  imports: [FormsModule, RouterModule, MovieCardDemoComponent],
  templateUrl: './componentes-page.component.html',
  styleUrl: './componentes-page.component.css',
})
export class ComponentesPageComponent {
  private movieService = inject(MovieService);

  activeTab = signal<string>('io');

  // Demo @Input / @Output
  peliculaActual: Movie = this.movieService.getMockMovies()[0];
  peliculaSeleccionada: Movie | null = null;
  favoritos: Movie[] = [];
  mostrarCard = true;

  // Demo two-way binding
  tituloEditado = 'Mi película favorita';

  setTab(tab: string) { this.activeTab.set(tab); }

  onSeleccionada(movie: Movie) { this.peliculaSeleccionada = movie; }

  onAgregadaFavoritos(movie: Movie) {
    if (!this.favoritos.find(f => f.id === movie.id)) {
      this.favoritos = [...this.favoritos, movie];
    }
  }

  cambiarPelicula() {
    const mocks = this.movieService.getMockMovies();
    const idx = mocks.findIndex(m => m.id === this.peliculaActual.id);
    this.peliculaActual = mocks[(idx + 1) % mocks.length];
  }

  toggleCard() { this.mostrarCard = !this.mostrarCard; }
}
```

```html
<!-- componentes-page.component.html -->
<div class="concepto-page">
  <a routerLink="/" class="back-link">← Inicio</a>
  <h1 class="page-title">Componentes</h1>
  <p class="page-subtitle">La unidad básica de Angular: selector + template + lógica.</p>

  <!-- Tabs Angular puro: signal + class binding -->
  <div class="tab-nav">
    <button class="tab-btn" [class.active]="activeTab() === 'io'" (click)="setTab('io')">@Input y @Output</button>
    <button class="tab-btn" [class.active]="activeTab() === 'twoway'" (click)="setTab('twoway')">Two-way Binding</button>
    <button class="tab-btn" [class.active]="activeTab() === 'lifecycle'" (click)="setTab('lifecycle')">Lifecycle Hooks</button>
  </div>

  <!-- TAB: @Input y @Output -->
  @if (activeTab() === 'io') {
    <div class="info-box">
      <p><strong>@Input</strong>: el padre le pasa datos al hijo mediante atributos del selector.</p>
      <p><strong>@Output</strong>: el hijo emite eventos que el padre escucha con <code>(evento)</code>.</p>
      <p>Patrón <strong>Smart / Dumb</strong>: el componente hijo solo recibe y emite — sin lógica de negocio propia.</p>
    </div>

    <div class="demo-box">
      <div class="d-flex gap-2 mb-3 flex-wrap">
        <button class="btn btn-primary" (click)="cambiarPelicula()">
          Cambiar película → dispara @Input
        </button>
        <button class="btn btn-outline-secondary" (click)="toggleCard()">
          {{ mostrarCard ? 'Destruir componente' : 'Crear componente' }}
        </button>
      </div>

      @if (mostrarCard) {
        <app-movie-card-demo
          [movie]="peliculaActual"
          [destacada]="true"
          (seleccionada)="onSeleccionada($event)"
          (agregadaFavoritos)="onAgregadaFavoritos($event)"
        />
      }

      @if (peliculaSeleccionada) {
        <div class="alert alert-success mt-3">
          ✅ <strong>@Output recibido en padre:</strong> {{ peliculaSeleccionada.title }}
        </div>
      }
      @if (favoritos.length > 0) {
        <div class="alert alert-info mt-2">
          ❤️ Favoritos agregados: {{ favoritos.length }} — último: {{ favoritos[favoritos.length - 1].title }}
        </div>
      }
      <p class="text-muted mt-2"><small>Abrí la consola para ver los lifecycle hooks en acción.</small></p>
    </div>
  }

  <!-- TAB: Two-way Binding -->
  @if (activeTab() === 'twoway') {
    <div class="info-box">
      <p><strong>[(ngModel)]</strong> combina @Input y @Output en una sola sintaxis — "banana in a box".</p>
      <p><code>[(prop)]</code> equivale a <code>[prop]="val"</code> + <code>(propChange)="val = $event"</code></p>
    </div>

    <div class="demo-box">
      <label class="form-label fw-bold">Editá el título:</label>
      <input class="form-control mb-3" [(ngModel)]="tituloEditado" placeholder="Escribe algo...">

      <div class="card bg-light">
        <div class="card-body">
          <p class="text-muted mb-1">Vista previa en tiempo real:</p>
          <h4>{{ tituloEditado || '(vacío)' }}</h4>
        </div>
      </div>
    </div>
  }

  <!-- TAB: Lifecycle Hooks -->
  @if (activeTab() === 'lifecycle') {
    <div class="info-box">
      <p>Angular llama a estos métodos en momentos específicos del ciclo de vida del componente:</p>
      <ul class="mb-0">
        <li><strong>ngOnInit</strong>: una vez al crear — ideal para cargar datos</li>
        <li><strong>ngOnChanges</strong>: cada vez que cambia un @Input</li>
        <li><strong>ngOnDestroy</strong>: al destruir — ideal para limpiar suscripciones</li>
      </ul>
    </div>

    <div class="demo-box">
      <div class="d-flex gap-2 mb-3 flex-wrap">
        <button class="btn btn-primary" (click)="cambiarPelicula()">
          Cambiar película → ngOnChanges
        </button>
        <button class="btn btn-danger" (click)="toggleCard()">
          {{ mostrarCard ? 'Destruir → ngOnDestroy' : 'Crear → ngOnInit' }}
        </button>
      </div>

      @if (mostrarCard) {
        <app-movie-card-demo
          [movie]="peliculaActual"
          (seleccionada)="onSeleccionada($event)"
          (agregadaFavoritos)="onAgregadaFavoritos($event)"
        />
      }
      <p class="text-muted mt-3"><small>Abrí la consola y usá los botones para ver cada hook en acción.</small></p>
    </div>
  }
</div>
```

```css
/* componentes-page.component.css */
/* Los estilos globales en styles.css ya cubren .concepto-page, .tab-nav, .tab-btn, .info-box, .demo-box */
```

---

## Task 8: Sección Módulos vs Standalone (Bootstrap + Angular puro)

**Files:**
- Create: `movie-manager/src/app/features/conceptos/modulos/modulos-page.component.{ts,html,css}`

- [ ] **Step 1: Crear ModulosPageComponent**

```ts
// movie-manager/src/app/features/conceptos/modulos/modulos-page.component.ts
import { Component, Input, signal } from '@angular/core';
import { RouterModule } from '@angular/router';

// ============================================================
// ESTE ARCHIVO SIRVE COMO DEMO DIDÁCTICO DE NgModule vs Standalone
//
// VERSIÓN ANTIGUA — NgModule (comentado, no funcional aquí):
// ============================================================
//
// // 1. Se necesita un módulo que declare y exporte el componente:
// @NgModule({
//   declarations: [GenreTagComponent],   // el componente SE DECLARA acá
//   imports: [CommonModule],
//   exports: [GenreTagComponent],        // SE EXPORTA para que otros lo usen
// })
// export class GenreTagModule {}
//
// // 2. El componente NO tiene imports en @Component:
// @Component({
//   selector: 'app-genre-tag',
//   // standalone: false (default antiguo — no standalone)
//   template: `<span class="badge">{{ genre }}</span>`
// })
// export class GenreTagComponent {
//   @Input() genre!: string;
// }
//
// // 3. El consumidor importa el MÓDULO completo (no el componente):
// @NgModule({
//   imports: [CommonModule, GenreTagModule],  // módulo entero
//   declarations: [MoviesPageComponent],
// })
// export class MoviesModule {}
//
// ============================================================
// VERSIÓN MODERNA — Standalone (funcional abajo):
// ============================================================

// Componente standalone de demo: no necesita módulo
@Component({
  selector: 'app-genre-tag',
  standalone: true,
  imports: [],
  template: `<span class="badge" [style.background]="color" style="margin: 3px; font-size: 0.85rem;">{{ genre }}</span>`,
})
export class GenreTagComponent {
  @Input() genre!: string;
  @Input() color: string = '#3f51b5';
}

// ============================================================

@Component({
  selector: 'app-modulos-page',
  standalone: true,
  imports: [RouterModule, GenreTagComponent],
  templateUrl: './modulos-page.component.html',
  styleUrl: './modulos-page.component.css',
})
export class ModulosPageComponent {
  activeTab = signal<string>('ngmodule');
  setTab(tab: string) { this.activeTab.set(tab); }

  generos = [
    { nombre: 'Acción', color: '#e53935' },
    { nombre: 'Drama', color: '#1565c0' },
    { nombre: 'Comedia', color: '#f57f17' },
    { nombre: 'Thriller', color: '#4a148c' },
    { nombre: 'Animación', color: '#2e7d32' },
  ];

  ngModuleCode = `// 1. Módulo que declara y exporta el componente
@NgModule({
  declarations: [GenreTagComponent],
  imports: [CommonModule],
  exports: [GenreTagComponent],
})
export class GenreTagModule {}

// 2. El componente no tiene imports propios
@Component({
  selector: 'app-genre-tag',
  template: \`<span>{{ genre }}</span>\`
})
export class GenreTagComponent {
  @Input() genre!: string;
}

// 3. El consumidor importa el MÓDULO (no el componente)
@NgModule({
  imports: [GenreTagModule],
  declarations: [MoviesPageComponent],
})
export class MoviesModule {}`;

  standaloneCode = `// El componente se autogestiona — no necesita módulo
@Component({
  selector: 'app-genre-tag',
  standalone: true,      // ← ya no necesita módulo
  imports: [],           // ← importa lo que necesita directamente
  template: \`<span>{{ genre }}</span>\`
})
export class GenreTagComponent {
  @Input() genre!: string;
}

// El consumidor importa el COMPONENTE directamente
@Component({
  selector: 'app-movies-page',
  standalone: true,
  imports: [GenreTagComponent],  // ← directo, sin módulo intermediario
})
export class MoviesPageComponent {}`;
}
```

```html
<!-- modulos-page.component.html -->
<div class="concepto-page">
  <a routerLink="/" class="back-link">← Inicio</a>
  <h1 class="page-title">Módulos vs Standalone</h1>
  <p class="page-subtitle">Angular 19 usa standalone por defecto. NgModule era el enfoque clásico hasta Angular 14.</p>

  <div class="tab-nav">
    <button class="tab-btn" [class.active]="activeTab() === 'ngmodule'" (click)="setTab('ngmodule')">NgModule (Clásico)</button>
    <button class="tab-btn" [class.active]="activeTab() === 'standalone'" (click)="setTab('standalone')">Standalone (Moderno)</button>
    <button class="tab-btn" [class.active]="activeTab() === 'comparacion'" (click)="setTab('comparacion')">Comparación</button>
  </div>

  @if (activeTab() === 'ngmodule') {
    <div class="alert alert-warning d-flex align-items-start gap-2">
      <i class="bi bi-clock-history fs-5"></i>
      <div>
        <strong>Enfoque anterior a Angular 14.</strong> Lo vas a encontrar en proyectos legacy y documentación vieja. Ya no es el recomendado.
      </div>
    </div>
    <div class="demo-box">
      <h6 class="fw-bold mb-3">Código con NgModule:</h6>
      <pre class="code-block">{{ ngModuleCode }}</pre>
      <div class="alert alert-danger mt-3 mb-0">
        ❌ <strong>Problema:</strong> para usar un componente hay que conocer su módulo, importar el módulo completo y mantener declarations sincronizadas.
      </div>
    </div>
  }

  @if (activeTab() === 'standalone') {
    <div class="alert alert-success d-flex align-items-start gap-2">
      <i class="bi bi-check-circle fs-5"></i>
      <div>
        <strong>Recomendado desde Angular 17, default en Angular 19.</strong> Sin módulos intermediarios.
      </div>
    </div>
    <div class="demo-box">
      <h6 class="fw-bold mb-3">Código Standalone:</h6>
      <pre class="code-block">{{ standaloneCode }}</pre>
      <div class="alert alert-success mt-3 mb-0">
        ✅ <strong>Ventaja:</strong> el componente se importa directo. Mejor tree-shaking, menos boilerplate.
      </div>
    </div>

    <div class="demo-box mt-3">
      <h6 class="fw-bold mb-3">Demo en vivo: <code>app-genre-tag</code> (standalone, importado directamente)</h6>
      <div class="d-flex flex-wrap">
        @for (genero of generos; track genero.nombre) {
          <app-genre-tag [genre]="genero.nombre" [color]="genero.color" />
        }
      </div>
    </div>
  }

  @if (activeTab() === 'comparacion') {
    <div class="row g-3">
      <div class="col-md-6">
        <div class="card h-100 border-danger">
          <div class="card-header bg-danger text-white">NgModule</div>
          <div class="card-body">
            <ul class="list-unstyled mb-0">
              <li>❌ Declarar componente en módulo</li>
              <li>❌ Exportar si se usa afuera</li>
              <li>❌ Importar módulo completo en consumidor</li>
              <li>❌ Archivos adicionales (el módulo)</li>
              <li>❌ Bundle potencialmente más grande</li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card h-100 border-success">
          <div class="card-header bg-success text-white">Standalone</div>
          <div class="card-body">
            <ul class="list-unstyled mb-0">
              <li>✅ Componente importa sus dependencias</li>
              <li>✅ Se importa directamente donde se usa</li>
              <li>✅ Sin módulo intermediario</li>
              <li>✅ Menos archivos, menos boilerplate</li>
              <li>✅ Mejor tree-shaking</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  }
</div>
```

```css
/* modulos-page.component.css */
/* Estilos globales en styles.css cubren lo necesario */
```

---

## Task 9: Sección Directivas (Bootstrap + Angular puro)

**Files:**
- Create: `movie-manager/src/app/features/conceptos/directivas/highlight.directive.ts`
- Create: `movie-manager/src/app/features/conceptos/directivas/if-logged.directive.ts`
- Create: `movie-manager/src/app/features/conceptos/directivas/directivas-page.component.{ts,html,css}`

- [ ] **Step 1: Crear HighlightDirective**

```ts
// movie-manager/src/app/features/conceptos/directivas/highlight.directive.ts
import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appHighlight]',
  standalone: true,
})
export class HighlightDirective {
  @Input() appHighlight: string = '#fffde7';
  @Input() highlightTextColor: string = '#e65100';

  constructor(private el: ElementRef) {}

  @HostListener('mouseenter')
  onMouseEnter() {
    this.el.nativeElement.style.backgroundColor = this.appHighlight;
    this.el.nativeElement.style.color = this.highlightTextColor;
    this.el.nativeElement.style.transition = 'all 0.2s';
  }

  @HostListener('mouseleave')
  onMouseLeave() {
    this.el.nativeElement.style.backgroundColor = '';
    this.el.nativeElement.style.color = '';
  }
}
```

- [ ] **Step 2: Crear IfLoggedDirective**

```ts
// movie-manager/src/app/features/conceptos/directivas/if-logged.directive.ts
import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appIfLogged]',
  standalone: true,
})
export class IfLoggedDirective {
  private hasView = false;

  @Input() set appIfLogged(condition: boolean) {
    if (condition && !this.hasView) {
      this.viewContainer.createEmbeddedView(this.template);
      this.hasView = true;
    } else if (!condition && this.hasView) {
      this.viewContainer.clear();
      this.hasView = false;
    }
  }

  constructor(
    private template: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
  ) {}
}
```

- [ ] **Step 3: Crear DirectivasPageComponent**

```ts
// movie-manager/src/app/features/conceptos/directivas/directivas-page.component.ts
import { Component, signal, inject } from '@angular/core';
import { NgFor, NgSwitch, NgSwitchCase, NgSwitchDefault, UpperCasePipe } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HighlightDirective } from './highlight.directive';
import { IfLoggedDirective } from './if-logged.directive';
import { MovieService } from '../../movies/services/movie.service';
import { Movie } from '../../movies/models/movie.model';

@Component({
  selector: 'app-directivas-page',
  standalone: true,
  imports: [NgFor, NgSwitch, NgSwitchCase, NgSwitchDefault, UpperCasePipe, RouterModule, HighlightDirective, IfLoggedDirective],
  templateUrl: './directivas-page.component.html',
  styleUrl: './directivas-page.component.css',
})
export class DirectivasPageComponent {
  private movieService = inject(MovieService);

  activeTab = signal<string>('ngfor');
  setTab(tab: string) { this.activeTab.set(tab); }

  peliculas: Movie[] = this.movieService.getMockMovies();
  peliculaSeleccionada: Movie = this.peliculas[0];
  estaLogueado = false;

  seleccionarPelicula(movie: Movie) { this.peliculaSeleccionada = movie; }
  toggleLogin() { this.estaLogueado = !this.estaLogueado; }
}
```

```html
<!-- directivas-page.component.html -->
<div class="concepto-page">
  <a routerLink="/" class="back-link">← Inicio</a>
  <h1 class="page-title">Directivas</h1>
  <p class="page-subtitle">Extienden el comportamiento del HTML. Hay built-in y personalizadas.</p>

  <div class="tab-nav">
    <button class="tab-btn" [class.active]="activeTab() === 'ngfor'" (click)="setTab('ngfor')">*ngFor / @for</button>
    <button class="tab-btn" [class.active]="activeTab() === 'ngswitch'" (click)="setTab('ngswitch')">ngSwitch / @switch</button>
    <button class="tab-btn" [class.active]="activeTab() === 'routerlink'" (click)="setTab('routerlink')">[routerLink]</button>
    <button class="tab-btn" [class.active]="activeTab() === 'highlight'" (click)="setTab('highlight')">appHighlight</button>
    <button class="tab-btn" [class.active]="activeTab() === 'iflogged'" (click)="setTab('iflogged')">*appIfLogged</button>
  </div>

  @if (activeTab() === 'ngfor') {
    <div class="info-box">
      <p><strong>*ngFor</strong> (clásico) y <strong>@for</strong> (Angular 17+) repiten elementos de una lista.</p>
      <p>El <code>@for</code> requiere <code>track</code> para identificar elementos eficientemente.</p>
    </div>
    <div class="row g-3">
      <div class="col-md-6">
        <div class="demo-box">
          <h6 class="fw-bold">*ngFor (clásico)</h6>
          <code class="d-block bg-light p-2 rounded mb-3">*ngFor="let p of peliculas"</code>
          <ul class="list-group">
            <li class="list-group-item" *ngFor="let p of peliculas">{{ p.title }}</li>
          </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="demo-box">
          <h6 class="fw-bold">@for (moderno)</h6>
          <code class="d-block bg-light p-2 rounded mb-3">@for (p of peliculas; track p.id)</code>
          <ul class="list-group">
            @for (p of peliculas; track p.id) {
              <li class="list-group-item">{{ p.title }}</li>
            }
          </ul>
        </div>
      </div>
    </div>
  }

  @if (activeTab() === 'ngswitch') {
    <div class="info-box">
      <p>Muestra un bloque según el valor de una expresión. Como un <code>switch/case</code> en el template.</p>
    </div>
    <div class="demo-box">
      <p class="fw-bold mb-2">Seleccioná una película:</p>
      <div class="d-flex flex-wrap gap-2 mb-3">
        @for (p of peliculas; track p.id) {
          <button class="btn btn-sm btn-outline-primary" (click)="seleccionarPelicula(p)">{{ p.title }}</button>
        }
      </div>
      <div [ngSwitch]="peliculaSeleccionada.original_language">
        <div *ngSwitchCase="'en'" class="alert alert-primary">🇺🇸 Película en inglés</div>
        <div *ngSwitchCase="'es'" class="alert alert-warning">🇦🇷 Película en español</div>
        <div *ngSwitchDefault class="alert alert-secondary">🌍 Idioma: {{ peliculaSeleccionada.original_language | uppercase }}</div>
      </div>
      <p class="text-muted"><small>Película actual: {{ peliculaSeleccionada.title }} ({{ peliculaSeleccionada.original_language }})</small></p>
    </div>
  }

  @if (activeTab() === 'routerlink') {
    <div class="info-box">
      <p><strong>[routerLink]</strong>: directiva de atributo que convierte cualquier elemento en un link de navegación SPA — sin recargar la página.</p>
      <p>A diferencia de <code>href</code>, no hace un request al servidor.</p>
    </div>
    <div class="demo-box">
      <p class="fw-bold mb-3">Links con routerLink:</p>
      <div class="d-flex flex-wrap gap-2">
        <a class="btn btn-primary" routerLink="/">Inicio</a>
        <a class="btn btn-secondary" routerLink="/movies">Películas</a>
        <a class="btn btn-outline-primary" routerLink="/conceptos/componentes">Componentes</a>
        <a class="btn btn-outline-secondary" routerLink="/conceptos/servicios">Servicios</a>
      </div>
    </div>
  }

  @if (activeTab() === 'highlight') {
    <div class="info-box">
      <p><strong>Directiva de atributo personalizada</strong>: modifica la apariencia o comportamiento de un elemento existente.</p>
      <p><code>appHighlight</code> escucha eventos del mouse con <code>@HostListener</code> y cambia el estilo del elemento.</p>
    </div>
    <div class="demo-box">
      <p class="fw-bold mb-3">Pasá el mouse sobre cada película:</p>
      <div class="d-flex flex-column gap-2">
        @for (p of peliculas; track p.id) {
          <div class="p-2 border rounded" appHighlight="#fff3e0" highlightTextColor="#e65100" style="cursor: default;">
            {{ p.title }}
          </div>
        }
      </div>
    </div>
  }

  @if (activeTab() === 'iflogged') {
    <div class="info-box">
      <p><strong>Directiva estructural personalizada</strong>: agrega o elimina elementos del DOM según una condición.</p>
      <p><code>*appIfLogged</code> funciona como <code>*ngIf</code> pero semánticamente ligado al estado de autenticación.</p>
    </div>
    <div class="demo-box">
      <div class="d-flex align-items-center gap-3 mb-3">
        <span>Estado: <strong>{{ estaLogueado ? '✅ Logueado' : '❌ No logueado' }}</strong></span>
        <button class="btn btn-sm" [class.btn-success]="!estaLogueado" [class.btn-danger]="estaLogueado" (click)="toggleLogin()">
          {{ estaLogueado ? 'Cerrar sesión' : 'Iniciar sesión' }}
        </button>
      </div>
      <hr>
      <div *appIfLogged="estaLogueado">
        <div class="alert alert-success">
          🎬 Contenido exclusivo para usuarios logueados:
          <ul class="mb-0 mt-2">
            @for (p of peliculas.slice(0, 3); track p.id) {
              <li>{{ p.title }}</li>
            }
          </ul>
        </div>
      </div>
      <div *appIfLogged="!estaLogueado">
        <div class="alert alert-warning">🔒 Iniciá sesión para ver el contenido.</div>
      </div>
    </div>
  }
</div>
```

```css
/* directivas-page.component.css */
/* Estilos globales en styles.css cubren lo necesario */
```

---

## Task 10: Sección Servicios (Bootstrap + Angular puro)

**Files:**
- Create: `movie-manager/src/app/features/conceptos/servicios/servicios-page.component.{ts,html,css}`

- [ ] **Step 1: Crear ServiciosPageComponent**

```ts
// movie-manager/src/app/features/conceptos/servicios/servicios-page.component.ts
import { Component, signal, inject } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MovieService } from '../../movies/services/movie.service';
import { AuthService } from '../../auth/services/auth.service';

@Component({
  selector: 'app-servicios-page',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './servicios-page.component.html',
  styleUrl: './servicios-page.component.css',
})
export class ServiciosPageComponent {
  // Inyección con inject() — forma moderna (Angular 14+)
  private movieService = inject(MovieService);
  authService = inject(AuthService);

  activeTab = signal<string>('que-es');
  setTab(tab: string) { this.activeTab.set(tab); }

  peliculas = this.movieService.getMockMovies();

  serviceCode = `@Injectable({ providedIn: 'root' })  // singleton global
export class MovieService {
  movies = signal<Movie[]>([]);
  isLoading = signal(false);

  constructor(private http: HttpClient) {}

  loadPopularMovies() {
    this.isLoading.set(true);
    this.http.get('/api/movies').subscribe(data => {
      this.movies.set(data);
      this.isLoading.set(false);
    });
  }
}`;

  diCode = `// Forma 1: inject() — moderna (Angular 14+)
export class MoviesPageComponent {
  private movieService = inject(MovieService);
}

// Forma 2: constructor — clásica
export class MoviesPageComponent {
  constructor(private movieService: MovieService) {}
}`;

  singletonCode = `// ComponenteA — obtiene la instancia del servicio
private movieService = inject(MovieService);
// → Angular crea MovieService#1

// ComponenteB — en otra parte de la app
private movieService = inject(MovieService);
// → Angular entrega la MISMA MovieService#1

// Resultado: ambos componentes ven los mismos datos
// Si ComponenteA llama loadMovies(), ComponenteB ve el resultado.`;
}
```

```html
<!-- servicios-page.component.html -->
<div class="concepto-page">
  <a routerLink="/" class="back-link">← Inicio</a>
  <h1 class="page-title">Servicios</h1>
  <p class="page-subtitle">Centralizan la lógica de negocio y permiten compartir datos entre componentes.</p>

  <div class="tab-nav">
    <button class="tab-btn" [class.active]="activeTab() === 'que-es'" (click)="setTab('que-es')">¿Qué es un servicio?</button>
    <button class="tab-btn" [class.active]="activeTab() === 'di'" (click)="setTab('di')">Inyección de Dependencias</button>
    <button class="tab-btn" [class.active]="activeTab() === 'demo'" (click)="setTab('demo')">Demo en vivo</button>
  </div>

  @if (activeTab() === 'que-es') {
    <div class="info-box">
      <p>Un servicio es una clase con <code>@Injectable</code> que Angular puede inyectar en cualquier componente.</p>
      <p>Con <code>providedIn: 'root'</code> hay <strong>una sola instancia en toda la app</strong> (patrón Singleton).</p>
    </div>
    <div class="demo-box">
      <h6 class="fw-bold mb-3">Anatomía de un servicio:</h6>
      <pre class="code-block">{{ serviceCode }}</pre>
    </div>
  }

  @if (activeTab() === 'di') {
    <div class="info-box">
      <p>Angular crea y gestiona las instancias. Vos solo declarás qué necesitás — Angular lo provee.</p>
      <p>Esto se llama <strong>Inversión de Control</strong>: el framework controla la creación de objetos.</p>
    </div>
    <div class="demo-box mb-3">
      <h6 class="fw-bold mb-3">Cómo inyectar un servicio:</h6>
      <pre class="code-block">{{ diCode }}</pre>
    </div>
    <div class="demo-box">
      <h6 class="fw-bold mb-3">Singleton: una sola instancia compartida</h6>
      <pre class="code-block">{{ singletonCode }}</pre>
    </div>
  }

  @if (activeTab() === 'demo') {
    <div class="info-box">
      <p>Esta página inyecta <strong>MovieService</strong> y <strong>AuthService</strong> — los mismos que usa el resto de la app.</p>
    </div>
    <div class="row g-3">
      <div class="col-md-6">
        <div class="demo-box h-100">
          <h6 class="fw-bold">MovieService (instancia compartida)</h6>
          <p class="text-muted">{{ peliculas.length }} películas disponibles:</p>
          <ul class="list-group list-group-flush">
            @for (p of peliculas; track p.id) {
              <li class="list-group-item py-1">{{ p.title }}</li>
            }
          </ul>
        </div>
      </div>
      <div class="col-md-6">
        <div class="demo-box h-100">
          <h6 class="fw-bold">AuthService (estado compartido)</h6>
          <p class="mb-3">Estado actual del login:</p>
          <div class="alert" [class.alert-success]="authService.isLogged()" [class.alert-secondary]="!authService.isLogged()">
            {{ authService.isLogged() ? '✅ Usuario logueado' : '❌ No logueado' }}
          </div>
          <p class="text-muted"><small>Este es el mismo estado que ve el Navbar arriba.</small></p>
        </div>
      </div>
    </div>
  }
</div>
```

```css
/* servicios-page.component.css */
```

---

## Task 11: Sección Navegación (Bootstrap + Angular puro)

**Files:**
- Create: `movie-manager/src/app/features/conceptos/navegacion/navegacion-page.component.{ts,html,css}`

- [ ] **Step 1: Crear NavegacionPageComponent**

```ts
// movie-manager/src/app/features/conceptos/navegacion/navegacion-page.component.ts
import { Component, signal, inject } from '@angular/core';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-navegacion-page',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './navegacion-page.component.html',
  styleUrl: './navegacion-page.component.css',
})
export class NavegacionPageComponent {
  private router = inject(Router);
  activeTab = signal<string>('routing');
  setTab(tab: string) { this.activeTab.set(tab); }

  navegarPorCodigo() {
    this.router.navigate(['/conceptos/servicios']);
  }

  routesCode = `// app.routes.ts
export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'movies', component: MoviesPageComponent },
  { path: 'login', component: LoginComponent },

  // Lazy loading: el componente se carga solo cuando se navega a la ruta
  {
    path: 'conceptos/componentes',
    loadComponent: () =>
      import('./conceptos/componentes/componentes-page.component')
        .then(m => m.ComponentesPageComponent),
  },

  { path: '**', component: NotFoundComponent },  // 404 — wildcard
];`;

  guardCode = `// auth.guard.ts
export const authGuard: CanActivateFn = () => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (authService.isLogged()) {
    return true;          // ✅ permite el acceso
  }
  router.navigate(['/login']);
  return false;           // ❌ bloquea y redirige
};

// En las rutas — proteger una ruta:
{
  path: 'movies',
  component: MoviesPageComponent,
  canActivate: [authGuard]    // ← guard aplicado
}`;
}
```

```html
<!-- navegacion-page.component.html -->
<div class="concepto-page">
  <a routerLink="/" class="back-link">← Inicio</a>
  <h1 class="page-title">Navegación</h1>
  <p class="page-subtitle">Angular Router gestiona la navegación entre vistas sin recargar la página (SPA).</p>

  <div class="tab-nav">
    <button class="tab-btn" [class.active]="activeTab() === 'routing'" (click)="setTab('routing')">Routing básico</button>
    <button class="tab-btn" [class.active]="activeTab() === 'guardas'" (click)="setTab('guardas')">Guardas</button>
  </div>

  @if (activeTab() === 'routing') {
    <div class="info-box">
      <p>Cada ruta mapea una URL a un componente. Angular muestra el componente en <code>&lt;router-outlet&gt;</code>.</p>
      <p><strong>Lazy loading</strong>: los componentes se cargan solo cuando se navega a su ruta — mejora el tiempo de carga inicial.</p>
    </div>
    <div class="demo-box mb-3">
      <h6 class="fw-bold mb-3">Configuración de rutas:</h6>
      <pre class="code-block">{{ routesCode }}</pre>
    </div>
    <div class="demo-box">
      <h6 class="fw-bold mb-3">Formas de navegar:</h6>
      <p class="mb-2"><strong>En el template:</strong> <code>[routerLink]="/ruta"</code></p>
      <p class="mb-3"><strong>Por código:</strong> <code>this.router.navigate(['/ruta'])</code></p>
      <div class="d-flex gap-2 flex-wrap">
        <a class="btn btn-primary" routerLink="/conceptos/componentes">Via routerLink</a>
        <button class="btn btn-outline-primary" (click)="navegarPorCodigo()">Via router.navigate()</button>
      </div>
    </div>
  }

  @if (activeTab() === 'guardas') {
    <div class="info-box">
      <p>Las <strong>guardas</strong> protegen rutas. Se ejecutan antes de activar el componente y pueden bloquear o redirigir.</p>
      <p>Angular soporta varios tipos: <code>canActivate</code>, <code>canDeactivate</code>, <code>canLoad</code>, entre otros.</p>
    </div>
    <div class="demo-box mb-3">
      <h6 class="fw-bold mb-3">Implementación del guard:</h6>
      <pre class="code-block">{{ guardCode }}</pre>
    </div>
    <div class="demo-box">
      <h6 class="fw-bold mb-3">Demo: ruta protegida</h6>
      <p>La ruta <code>/movies</code> está protegida con <code>authGuard</code>.</p>
      <p>Si no estás logueado, el guard te redirige automáticamente a <code>/login</code>.</p>
      <a class="btn btn-warning" routerLink="/movies">
        🔒 Ir a /movies (protegida)
      </a>
    </div>
  }
</div>
```

```css
/* navegacion-page.component.css */
```

---

## Task 12: Sección Signals vs Observables (Bootstrap + Angular puro)

**Files:**
- Create: `movie-manager/src/app/features/conceptos/signals-observables/signals-observables-page.component.{ts,html,css}`

- [ ] **Step 1: Crear SignalsObservablesPageComponent**

```ts
// movie-manager/src/app/features/conceptos/signals-observables/signals-observables-page.component.ts
import { Component, signal, computed, inject } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AsyncPipe } from '@angular/common';
import { Observable, of } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { MovieService } from '../../movies/services/movie.service';
import { Movie } from '../../movies/models/movie.model';

@Component({
  selector: 'app-signals-observables-page',
  standalone: true,
  imports: [RouterModule, AsyncPipe, ReactiveFormsModule],
  templateUrl: './signals-observables-page.component.html',
  styleUrl: './signals-observables-page.component.css',
})
export class SignalsObservablesPageComponent {
  private movieService = inject(MovieService);

  activeTab = signal<string>('observable');
  setTab(tab: string) { this.activeTab.set(tab); }

  // ─── PARTE 1: Observable simple ───
  generos$: Observable<string[]> = of([
    'Acción', 'Comedia', 'Drama', 'Terror', 'Ciencia Ficción', 'Animación',
  ]);

  // ─── PARTE 2: Signal simple ───
  favoritos = signal<Movie[]>([]);
  cantidadFavoritos = computed(() => this.favoritos().length);
  tieneFavoritos = computed(() => this.favoritos().length > 0);
  peliculas = this.movieService.getMockMovies();

  agregarFavorito(movie: Movie) {
    if (!this.favoritos().find(f => f.id === movie.id)) {
      this.favoritos.update(favs => [...favs, movie]);
    }
  }

  quitarFavorito(movie: Movie) {
    this.favoritos.update(favs => favs.filter(f => f.id !== movie.id));
  }

  esFavorito(movie: Movie): boolean {
    return !!this.favoritos().find(f => f.id === movie.id);
  }

  // ─── PARTE 3: Combinados — búsqueda con debounce ───
  searchControl = new FormControl('');
  resultados = signal<Movie[]>([]);
  buscando = signal(false);

  // Observable hace el pipeline: debounce + HTTP + error handling
  resultadosBusqueda$ = this.searchControl.valueChanges.pipe(
    debounceTime(300),
    distinctUntilChanged(),
    switchMap(query => this.movieService.searchMovies(query ?? ''))
  );

  // computed: deriva estado del signal
  resultadosDestacados = computed(() =>
    this.resultados().filter(m => (m.vote_average ?? 0) >= 8)
  );

  constructor() {
    this.resultadosBusqueda$.subscribe(movies => {
      this.resultados.set(movies);
      this.buscando.set(false);
    });

    this.searchControl.valueChanges.subscribe(() => {
      if (this.searchControl.value) this.buscando.set(true);
    });
  }
}
```

```html
<!-- signals-observables-page.component.html -->
<div class="concepto-page">
  <a routerLink="/" class="back-link">← Inicio</a>
  <h1 class="page-title">Signals vs Observables</h1>
  <p class="page-subtitle">No son alternativas — se complementan. Cada uno brilla en su contexto.</p>

  <div class="tab-nav">
    <button class="tab-btn" [class.active]="activeTab() === 'observable'" (click)="setTab('observable')">1. Observable solo</button>
    <button class="tab-btn" [class.active]="activeTab() === 'signal'" (click)="setTab('signal')">2. Signal solo</button>
    <button class="tab-btn" [class.active]="activeTab() === 'combinados'" (click)="setTab('combinados')">3. Combinados</button>
  </div>

  @if (activeTab() === 'observable') {
    <div class="info-box">
      <p><strong>Observable</strong>: un stream de valores a lo largo del tiempo. Puede emitir múltiples valores, errores, y completar.</p>
      <p>El template usa <code>| async</code> para suscribirse y desuscribirse automáticamente.</p>
      <p>Ideal para: HTTP, WebSockets, eventos del usuario con operadores (debounce, retry, etc.).</p>
    </div>
    <div class="demo-box">
      <h6 class="fw-bold mb-1">Template:</h6>
      <code class="d-block bg-light p-2 rounded mb-3">&#64;for (genero of (generos$ | async) ?? []; track genero)</code>
      <h6 class="fw-bold mb-2">Géneros (desde Observable con | async):</h6>
      <div class="d-flex flex-wrap gap-2">
        @for (genero of (generos$ | async) ?? []; track genero) {
          <span class="badge bg-primary fs-6">{{ genero }}</span>
        }
      </div>
      <p class="text-muted mt-3 mb-0"><small>El <code>async pipe</code> gestiona la suscripción automáticamente — no hay <code>.subscribe()</code> ni <code>.unsubscribe()</code>.</small></p>
    </div>
  }

  @if (activeTab() === 'signal') {
    <div class="info-box">
      <p><strong>Signal</strong>: un valor reactivo con estado actual. Siempre tiene un valor. No requiere suscripción.</p>
      <p>Se lee con <code>signal()</code> en el template. <code>computed()</code> deriva valores automáticamente.</p>
      <p>Ideal para: estado local, estado UI, valores derivados de otro estado.</p>
    </div>
    <div class="demo-box">
      <h6 class="fw-bold mb-1">Favoritos — <span class="badge bg-danger">{{ cantidadFavoritos() }}</span> seleccionadas</h6>
      <p class="text-muted"><small><code>cantidadFavoritos = computed(() => favoritos().length)</code></small></p>
      <ul class="list-group mb-3">
        @for (p of peliculas; track p.id) {
          <li class="list-group-item d-flex justify-content-between align-items-center">
            {{ p.title }}
            @if (esFavorito(p)) {
              <button class="btn btn-sm btn-danger" (click)="quitarFavorito(p)">❤️ Quitar</button>
            } @else {
              <button class="btn btn-sm btn-outline-danger" (click)="agregarFavorito(p)">🤍 Agregar</button>
            }
          </li>
        }
      </ul>
      @if (tieneFavoritos()) {
        <div class="alert alert-info mb-0">
          <strong>Favoritos (signal):</strong>
          @for (f of favoritos(); track f.id) {
            <span class="badge bg-danger ms-1">{{ f.title }}</span>
          }
        </div>
      }
    </div>
  }

  @if (activeTab() === 'combinados') {
    <div class="info-box">
      <p><strong>Observable</strong> maneja el stream (eventos del input + HTTP con debounce).</p>
      <p><strong>Signal</strong> guarda y deriva el estado de los resultados.</p>
      <p>Cada uno hace lo que mejor sabe: Observable para el flujo asíncrono, Signal para el estado.</p>
    </div>
    <div class="demo-box">
      <label class="form-label fw-bold">Buscar película:</label>
      <input class="form-control mb-3" [formControl]="searchControl" placeholder="Ej: Inception...">

      @if (buscando()) {
        <div class="d-flex align-items-center gap-2 text-muted mb-3">
          <div class="spinner-border spinner-border-sm"></div>
          <span>Buscando...</span>
        </div>
      }

      @if (resultados().length > 0) {
        <div class="d-flex justify-content-between align-items-center mb-2">
          <span class="fw-bold">Resultados: {{ resultados().length }}</span>
          <span class="badge bg-warning text-dark">⭐ Destacados (≥8): {{ resultadosDestacados().length }}</span>
        </div>
        <ul class="list-group">
          @for (movie of resultados(); track movie.id) {
            <li class="list-group-item d-flex justify-content-between align-items-center">
              {{ movie.title }}
              @if ((movie.vote_average ?? 0) >= 8) {
                <span class="badge bg-warning text-dark">⭐ {{ movie.vote_average }}</span>
              }
            </li>
          }
        </ul>
      }
    </div>
  }
</div>
```

```css
/* signals-observables-page.component.css */
```

---

## Task 13: Sección Estado (Bootstrap + Angular puro)

**Files:**
- Create: `movie-manager/src/app/features/conceptos/estado/estado-page.component.{ts,html,css}`

- [ ] **Step 1: Crear EstadoPageComponent**

```ts
// movie-manager/src/app/features/conceptos/estado/estado-page.component.ts
import { Component, signal, inject } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../auth/services/auth.service';

@Component({
  selector: 'app-estado-page',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './estado-page.component.html',
  styleUrl: './estado-page.component.css',
})
export class EstadoPageComponent {
  authService = inject(AuthService);
  activeTab = signal<string>('problema');
  setTab(tab: string) { this.activeTab.set(tab); }

  problemCode = `// AuthService ANTES (sin reactividad)
export class AuthService {
  private isLogged = false;     // booleano simple

  login() { this.isLogged = true; }
  isUserLogged() { return this.isLogged; }
}

// NavbarComponent — el problema:
export class NavbarComponent {
  // Angular tiene que llamar isUserLogged() en CADA ciclo
  // de detección de cambios para saber si el estado cambió.
  // No hay notificación automática.
  get estaLogueado() {
    return this.authService.isUserLogged();
  }
}`;

  solutionCode = `// AuthService AHORA (con signal)
export class AuthService {
  isLogged = signal(false);     // signal reactivo

  login() { this.isLogged.set(true); }
  logout() { this.isLogged.set(false); }
}

// NavbarComponent — la solución:
export class NavbarComponent {
  authService = inject(AuthService);
  // Template: @if (authService.isLogged()) { ... }
  //
  // Angular sabe que el template depende de isLogged().
  // Cuando isLogged cambia → solo el Navbar se re-renderiza.
  // Sin polling. Sin detectChanges(). Sin boilerplate.
}`;

  simularLogin() { this.authService.login('user', '1234'); }
  simularLogout() { this.authService.logout(); }
}
```

```html
<!-- estado-page.component.html -->
<div class="concepto-page">
  <a routerLink="/" class="back-link">← Inicio</a>
  <h1 class="page-title">Estado</h1>
  <p class="page-subtitle">El estado reactivo permite que múltiples componentes reaccionen a cambios sin coordinación manual.</p>

  <div class="tab-nav">
    <button class="tab-btn" [class.active]="activeTab() === 'problema'" (click)="setTab('problema')">El Problema</button>
    <button class="tab-btn" [class.active]="activeTab() === 'solucion'" (click)="setTab('solucion')">La Solución</button>
    <button class="tab-btn" [class.active]="activeTab() === 'demo'" (click)="setTab('demo')">Demo en vivo</button>
  </div>

  @if (activeTab() === 'problema') {
    <div class="alert alert-warning">
      Con un booleano simple, cuando el estado cambia en el servicio, los componentes que lo usan <strong>no se enteran automáticamente</strong>.
    </div>
    <div class="demo-box">
      <h6 class="fw-bold mb-3">AuthService sin reactividad:</h6>
      <pre class="code-block">{{ problemCode }}</pre>
      <div class="alert alert-danger mt-3 mb-0">
        ❌ El Navbar debe consultar el estado en cada ciclo de detección de cambios. No escala. Puede causar cambios perdidos si se usa OnPush change detection.
      </div>
    </div>
  }

  @if (activeTab() === 'solucion') {
    <div class="alert alert-success">
      Con un <strong>signal</strong>, Angular sabe exactamente qué componentes leen ese valor y los actualiza automáticamente cuando cambia.
    </div>
    <div class="demo-box">
      <h6 class="fw-bold mb-3">AuthService con signal:</h6>
      <pre class="code-block">{{ solutionCode }}</pre>
      <div class="alert alert-success mt-3 mb-0">
        ✅ Cuando <code>isLogged</code> cambia, Angular actualiza <strong>solo los componentes que lo leen</strong>. Fine-grained reactivity sin overhead.
      </div>
    </div>
  }

  @if (activeTab() === 'demo') {
    <div class="info-box">
      <p>Usá los botones para cambiar el estado de <strong>AuthService.isLogged</strong> y observá cómo el <strong>Navbar</strong> (arriba) y esta sección reaccionan automáticamente.</p>
    </div>
    <div class="demo-box">
      <div class="d-flex align-items-center gap-3 mb-3 p-3 rounded" [class.bg-success]="authService.isLogged()" [class.bg-secondary]="!authService.isLogged()" style="color: white;">
        <span class="fs-4">{{ authService.isLogged() ? '✅' : '❌' }}</span>
        <span class="fw-bold">{{ authService.isLogged() ? 'Usuario logueado' : 'No logueado' }}</span>
      </div>
      <div class="d-flex gap-2">
        <button class="btn btn-success" [disabled]="authService.isLogged()" (click)="simularLogin()">
          Simular login
        </button>
        <button class="btn btn-danger" [disabled]="!authService.isLogged()" (click)="simularLogout()">
          Simular logout
        </button>
      </div>
      <p class="text-muted mt-3"><small>Mirá el Navbar arriba — cambia sin que nadie le avise explícitamente.</small></p>
    </div>
  }
</div>
```

```css
/* estado-page.component.css */
```

---

## Task 14: Sección Angular Material (showcase completo)

**Files:**
- Create: `movie-manager/src/app/features/conceptos/material/material-page.component.{ts,html,css}`

- [ ] **Step 1: Crear MaterialPageComponent**

```ts
// movie-manager/src/app/features/conceptos/material/material-page.component.ts
import { Component, signal, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatChipsModule } from '@angular/material/chips';
import { MatBadgeModule } from '@angular/material/badge';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTabsModule } from '@angular/material/tabs';

@Component({
  selector: 'app-material-page',
  standalone: true,
  imports: [
    FormsModule, RouterModule,
    MatCardModule, MatButtonModule, MatFormFieldModule, MatInputModule,
    MatChipsModule, MatBadgeModule, MatProgressSpinnerModule, MatProgressBarModule,
    MatTooltipModule, MatDividerModule, MatIconModule, MatSlideToggleModule, MatTabsModule,
  ],
  templateUrl: './material-page.component.html',
  styleUrl: './material-page.component.css',
})
export class MaterialPageComponent {
  private snackBar = inject(MatSnackBar);

  inputValor = '';
  toggleActivo = false;
  progreso = 65;

  importCode = `// En el componente standalone — importar directo:
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';

@Component({
  standalone: true,
  imports: [MatCardModule, MatButtonModule],
  template: \`
    <mat-card>
      <mat-card-content>Contenido</mat-card-content>
      <mat-card-actions>
        <button mat-raised-button color="primary">Acción</button>
      </mat-card-actions>
    </mat-card>
  \`
})`;

  mostrarSnackbar() {
    this.snackBar.open('¡Acción ejecutada!', 'Cerrar', { duration: 3000 });
  }

  mostrarSnackbarError() {
    this.snackBar.open('Error al procesar la solicitud', 'Reintentar', { duration: 4000 });
  }
}
```

```html
<!-- material-page.component.html -->
<div class="concepto-page">
  <a routerLink="/" class="back-link">← Inicio</a>
  <h1 class="page-title">Angular Material</h1>
  <p class="page-subtitle">Biblioteca de componentes UI que siguen Material Design de Google. A diferencia de Bootstrap (CSS puro), son componentes Angular con su propia lógica.</p>

  <div class="info-box mb-4">
    <p><strong>Diferencia clave con Bootstrap:</strong> Los componentes Material (<code>mat-card</code>, <code>mat-button</code>) son componentes Angular. Tienen @Input, @Output, servicios internos. Bootstrap son solo clases CSS.</p>
    <p>Se importan como cualquier componente standalone en el array <code>imports: []</code>.</p>
  </div>

  <mat-tab-group>

    <mat-tab label="Cómo importar">
      <div class="py-4">
        <pre class="code-block">{{ importCode }}</pre>
      </div>
    </mat-tab>

    <mat-tab label="Botones">
      <div class="py-4">
        <h6 class="fw-bold mb-3">Variantes de mat-button:</h6>
        <div class="d-flex flex-wrap gap-3 mb-4">
          <button mat-button>Básico</button>
          <button mat-raised-button>Raised</button>
          <button mat-stroked-button>Stroked</button>
          <button mat-flat-button>Flat</button>
        </div>
        <mat-divider></mat-divider>
        <div class="d-flex flex-wrap gap-3 my-4">
          <button mat-raised-button color="primary">Primary</button>
          <button mat-raised-button color="accent">Accent</button>
          <button mat-raised-button color="warn">Warn</button>
          <button mat-raised-button disabled>Disabled</button>
        </div>
        <mat-divider></mat-divider>
        <div class="d-flex flex-wrap gap-3 mt-4 align-items-center">
          <button mat-icon-button color="primary"><mat-icon>home</mat-icon></button>
          <button mat-icon-button color="accent"><mat-icon>star</mat-icon></button>
          <button mat-fab color="primary"><mat-icon>add</mat-icon></button>
          <button mat-mini-fab color="warn"><mat-icon>delete</mat-icon></button>
        </div>
      </div>
    </mat-tab>

    <mat-tab label="Formularios">
      <div class="py-4">
        <mat-form-field appearance="outline" class="w-100 mb-3">
          <mat-label>Nombre de la película</mat-label>
          <input matInput [(ngModel)]="inputValor" placeholder="Ej: Inception">
          <mat-icon matSuffix>movie</mat-icon>
        </mat-form-field>
        @if (inputValor) {
          <p>Escribiste: <strong>{{ inputValor }}</strong></p>
        }
        <mat-slide-toggle [(ngModel)]="toggleActivo" color="primary">
          Disponible en streaming: {{ toggleActivo ? 'Sí' : 'No' }}
        </mat-slide-toggle>
      </div>
    </mat-tab>

    <mat-tab label="Chips y Badges">
      <div class="py-4">
        <h6 class="fw-bold mb-3">mat-chip:</h6>
        <div class="d-flex flex-wrap gap-2 mb-4">
          <mat-chip>Acción</mat-chip>
          <mat-chip>Drama</mat-chip>
          <mat-chip color="primary" highlighted>Ciencia Ficción</mat-chip>
          <mat-chip color="accent" highlighted>Comedia</mat-chip>
          <mat-chip color="warn" highlighted>Terror</mat-chip>
        </div>
        <h6 class="fw-bold mb-3">matBadge:</h6>
        <div class="d-flex gap-4 align-items-center">
          <button mat-icon-button [matBadge]="3" matBadgeColor="warn">
            <mat-icon>notifications</mat-icon>
          </button>
          <button mat-icon-button [matBadge]="12" matBadgeColor="accent">
            <mat-icon>shopping_cart</mat-icon>
          </button>
        </div>
      </div>
    </mat-tab>

    <mat-tab label="Feedback">
      <div class="py-4">
        <h6 class="fw-bold mb-3">Progress:</h6>
        <div class="d-flex gap-4 align-items-center mb-3">
          <mat-progress-spinner mode="indeterminate" diameter="48"></mat-progress-spinner>
          <mat-progress-spinner mode="determinate" [value]="progreso" diameter="48"></mat-progress-spinner>
        </div>
        <mat-progress-bar mode="determinate" [value]="progreso" class="mb-2"></mat-progress-bar>
        <mat-progress-bar mode="indeterminate" class="mb-4"></mat-progress-bar>

        <h6 class="fw-bold mb-3">Snackbar y Tooltip:</h6>
        <div class="d-flex gap-3 flex-wrap">
          <button mat-raised-button color="primary" (click)="mostrarSnackbar()">Snackbar éxito</button>
          <button mat-raised-button color="warn" (click)="mostrarSnackbarError()">Snackbar error</button>
          <button mat-raised-button matTooltip="Información adicional" matTooltipPosition="above">Hover para tooltip</button>
        </div>
      </div>
    </mat-tab>

  </mat-tab-group>
</div>
```

```css
/* material-page.component.css */
.w-100 { width: 100%; }
```

---

## Task 15: Verificación final

- [ ] **Step 1: Build de producción sin errores**

```bash
cd /Users/lumpierrez/Downloads/ejemplos-de-clase-6-Angular-Advanced/movie-manager && npx ng build --configuration development 2>&1 | tail -15
```
Expected: Build exitoso sin errores de TypeScript.

- [ ] **Step 2: Verificar rutas**

Arrancar con `npx ng serve` y navegar a:
- `/` → 8 tarjetas de conceptos con Material
- `/conceptos/componentes` → tabs con @Input/@Output, two-way, lifecycle
- `/conceptos/modulos` → tabs NgModule vs Standalone
- `/conceptos/directivas` → 5 tabs con directivas
- `/conceptos/servicios` → 3 tabs con explicación y demo
- `/conceptos/navegacion` → 2 tabs con routing y guards
- `/conceptos/signals-observables` → 3 tabs progresivos
- `/conceptos/estado` → 3 tabs problema/solución/demo
- `/conceptos/material` → showcase Material con MatTabGroup
- `/movies` → redirige a `/login` si no está logueado

- [ ] **Step 3: Verificar reactividad del Navbar**

1. Ir a `/conceptos/estado`
2. Click "Simular login"
3. Confirmar que el Navbar muestra "Cerrar sesión" sin reload

- [ ] **Step 4: Verificar fallback mock**

1. Navegar a `/movies` estando logueado
2. Si hay internet → películas reales de TMDB
3. Si no hay internet → películas mock (Inception, The Dark Knight, etc.)
