# Angular Advanced - Movie Manager

### Temas
- Integración con API (usando signals)
- Ruteo avanzado y navegación
- Guardas y manejo de autenticación
