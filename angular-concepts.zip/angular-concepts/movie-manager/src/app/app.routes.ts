import { Routes } from '@angular/router';
import { HomeComponent } from './features/home/components/home.component';
import { MoviesPageComponent } from './features/movies/pages/movies-page/movies-page.component';
import { LoginComponent } from './features/auth/components/login/login.component';
import { NotFoundComponent } from './shared/components/not-found/not-found.component';
import { authGuard } from './core/guards/auth.guard';
import { ComponentesPageComponent } from './features/conceptos/componentes/componentes-page.component';
import { ModulosPageComponent } from './features/conceptos/modulos/modulos-page.component';
import { DirectivasPageComponent } from './features/conceptos/directivas/directivas-page.component';
import { ServiciosPageComponent } from './features/conceptos/servicios/servicios-page.component';
import { NavegacionPageComponent } from './features/conceptos/navegacion/navegacion-page.component';
import { SignalsObservablesPageComponent } from './features/conceptos/signals-observables/signals-observables-page.component';
import { EstadoPageComponent } from './features/conceptos/estado/estado-page.component';
import { MaterialPageComponent } from './features/conceptos/material/material-page.component';
import { PipesPageComponent } from './features/conceptos/pipes/pipes-page.component';
import { InterceptoresPageComponent } from './features/conceptos/interceptores/interceptores-page.component';

export const routes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'movies',
    component: MoviesPageComponent,
    canActivate: [authGuard]
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'conceptos/componentes',
    component: ComponentesPageComponent
  },
  {
    path: 'conceptos/modulos',
    component: ModulosPageComponent
  },
  {
    path: 'conceptos/directivas',
    component: DirectivasPageComponent
  },
  {
    path: 'conceptos/servicios',
    component: ServiciosPageComponent
  },
  {
    path: 'conceptos/navegacion',
    component: NavegacionPageComponent
  },
  {
    path: 'conceptos/signals-observables',
    component: SignalsObservablesPageComponent
  },
  {
    path: 'conceptos/estado',
    component: EstadoPageComponent
  },
  {
    path: 'conceptos/material',
    component: MaterialPageComponent
  },
  {
    path: 'conceptos/pipes',
    component: PipesPageComponent
  },
  {
    path: 'conceptos/interceptores',
    component: InterceptoresPageComponent
  },
  {
    path: '**',
    component: NotFoundComponent
  },
];
