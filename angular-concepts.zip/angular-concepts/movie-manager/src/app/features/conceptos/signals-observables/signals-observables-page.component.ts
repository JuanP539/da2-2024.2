import { Component, signal, computed, inject, OnInit } from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AsyncPipe } from '@angular/common';
import { Observable, of } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { MovieService } from '../../movies/services/movie.service';
import { Movie } from '../../movies/models/movie.model';

@Component({
  selector: 'app-signals-observables-page',
  standalone: true,
  imports: [RouterModule, AsyncPipe, ReactiveFormsModule],
  templateUrl: './signals-observables-page.component.html',
  styleUrl: './signals-observables-page.component.css',
})
export class SignalsObservablesPageComponent implements OnInit {
  private movieService = inject(MovieService);

  activeTab = signal<string>('observable');
  setTab(tab: string) { this.activeTab.set(tab); }

  // ─── PARTE 1: Observable simple ───

  //generos$ = this.http.get<string[]>('/api/generos');
  // of() es un operador que convierte un valor normal en un Observable. Lo usamos porque no tenemos un endpoint
  generos$: Observable<string[]> = of([
    'Acción', 'Comedia', 'Drama', 'Terror', 'Ciencia Ficción', 'Animación',
  ]);
  generosManual: string[] = [];

  searchField = new FormControl('');
  searchLog: string[] = [];

  ngOnInit() {
    this.generos$.subscribe(generos => {
      this.generosManual = generos;
    });

    this.searchField.valueChanges.subscribe(value => {
      this.searchLog.push(`"${value}"`);
    });
  }

  clearSearchLog() { this.searchLog = []; }

  // ─── PARTE 2: Signal simple ───
  favoritos = signal<Movie[]>([]);
  cantidadFavoritos = computed(() => this.favoritos().length);
  tieneFavoritos = computed(() => this.favoritos().length > 0);
  peliculas = this.movieService.getMockMovies();

  agregarFavorito(movie: Movie) {
    if (!this.favoritos().find(f => f.id === movie.id)) {
      this.favoritos.update(favs => [...favs, movie]);
    }
  }

  quitarFavorito(movie: Movie) {
    this.favoritos.update(favs => favs.filter(f => f.id !== movie.id));
  }

  esFavorito(movie: Movie): boolean {
    return !!this.favoritos().find(f => f.id === movie.id);
  }

  // ─── PARTE 3: Combinados — búsqueda con debounce ───
  searchControl = new FormControl('');
  resultados = signal<Movie[]>([]);
  buscando = signal(false);

  // Observable hace el pipeline: debounce + HTTP + error handling
  resultadosBusqueda$ = this.searchControl.valueChanges.pipe(
    debounceTime(300),
    distinctUntilChanged(),
    switchMap(query => this.movieService.searchMovies(query ?? ''))
  );

  // computed: deriva estado del signal
  resultadosDestacados = computed(() =>
    this.resultados().filter(m => (m.vote_average ?? 0) >= 8)
  );

  constructor() {
    this.resultadosBusqueda$.subscribe(movies => {
      this.resultados.set(movies);
      this.buscando.set(false);
    });

    this.searchControl.valueChanges.subscribe(() => {
      if (this.searchControl.value) this.buscando.set(true);
    });
  }
}
