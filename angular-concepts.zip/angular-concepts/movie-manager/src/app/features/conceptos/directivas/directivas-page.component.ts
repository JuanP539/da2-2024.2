import { Component, signal, inject } from '@angular/core';
import { NgFor, NgSwitch, NgSwitchCase, NgSwitchDefault, UpperCasePipe, NgStyle, NgClass } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HighlightDirective } from './highlight.directive';
import { IfLoggedDirective } from './if-logged.directive';
import { MovieService } from '../../movies/services/movie.service';
import { Movie } from '../../movies/models/movie.model';

@Component({
  selector: 'app-directivas-page',
  standalone: true,
  imports: [NgFor, NgSwitch, NgSwitchCase, NgSwitchDefault, UpperCasePipe, NgStyle, NgClass, RouterModule, HighlightDirective, IfLoggedDirective],
  templateUrl: './directivas-page.component.html',
  styleUrl: './directivas-page.component.css',
})
export class DirectivasPageComponent {
  private movieService = inject(MovieService);

  activeTab = signal<string>('ngfor');
  setTab(tab: string) { this.activeTab.set(tab); }

  peliculas: Movie[] = this.movieService.getMockMovies();
  peliculaSeleccionada: Movie = this.peliculas[0];
  estaLogueado = false;
  fontSize = 14;

  seleccionarPelicula(movie: Movie) { this.peliculaSeleccionada = movie; }
  toggleLogin() { this.estaLogueado = !this.estaLogueado; }
  increaseFontSize() { if (this.fontSize < 28) this.fontSize += 2; }
  decreaseFontSize() { if (this.fontSize > 10) this.fontSize -= 2; }

  getRatingColor(vote: number = 0): string {
    if (vote >= 7) return '#d4edda';
    if (vote >= 5) return '#fff3cd';
    return '#f8d7da';
  }

  getRatingClass(vote: number = 0): string {
    if (vote >= 7) return 'rating-high';
    if (vote >= 5) return 'rating-medium';
    return 'rating-low';
  }
}
