import { Component, Input, signal } from '@angular/core';
import { RouterModule } from '@angular/router';

// ============================================================
// ESTE ARCHIVO SIRVE COMO DEMO DIDÁCTICO DE NgModule vs Standalone
//
// VERSIÓN ANTIGUA — NgModule (comentado, solo ilustrativo):
// ============================================================
//
// // 1. Se necesita un módulo que declare y exporte el componente:
// @NgModule({
//   declarations: [GenreTagComponent],   // el componente SE DECLARA acá
//   imports: [CommonModule],
//   exports: [GenreTagComponent],        // SE EXPORTA para que otros lo usen
// })
// export class GenreTagModule {}
//
// // 2. El componente NO tiene imports en @Component:
// @Component({
//   selector: 'app-genre-tag',
//   // standalone: false  (default antiguo)
//   template: `<span class="badge">{{ genre }}</span>`
// })
// export class GenreTagComponent {
//   @Input() genre!: string;
// }
//
// // 3. El consumidor importa el MÓDULO completo (no el componente directo):
// @NgModule({
//   imports: [CommonModule, GenreTagModule],
//   declarations: [MoviesPageComponent],
// })
// export class MoviesModule {}
//
// ============================================================
// VERSIÓN MODERNA — Standalone (este código sí funciona):
// ============================================================

@Component({
  selector: 'app-genre-tag',
  standalone: true,
  imports: [],
  template: `<span class="badge" [style.background]="color" style="margin: 3px; font-size: 0.9rem; padding: 6px 12px;">{{ genre }}</span>`,
})
export class GenreTagComponent {
  @Input() genre!: string;
  @Input() color: string = '#3f51b5';
}

// ============================================================

@Component({
  selector: 'app-modulos-page',
  standalone: true,
  imports: [RouterModule, GenreTagComponent],
  templateUrl: './modulos-page.component.html',
  styleUrl: './modulos-page.component.css',
})
export class ModulosPageComponent {
  activeTab = signal<string>('ngmodule');
  setTab(tab: string) { this.activeTab.set(tab); }

  generos = [
    { nombre: 'Acción', color: '#e53935' },
    { nombre: 'Drama', color: '#1565c0' },
    { nombre: 'Comedia', color: '#f57f17' },
    { nombre: 'Thriller', color: '#4a148c' },
    { nombre: 'Animación', color: '#2e7d32' },
  ];

  ngModuleCode = `// 1. Módulo que declara y exporta el componente
@NgModule({
  declarations: [GenreTagComponent],
  imports: [CommonModule],
  exports: [GenreTagComponent],
})
export class GenreTagModule {}

// 2. El componente no tiene imports propios
@Component({
  selector: 'app-genre-tag',
  template: \`<span>{{ genre }}</span>\`
})
export class GenreTagComponent {
  @Input() genre!: string;
}

// 3. El consumidor importa el MÓDULO (no el componente)
@NgModule({
  imports: [GenreTagModule],
  declarations: [MoviesPageComponent],
})
export class MoviesModule {}`;

  standaloneCode = `// El componente se autogestiona — no necesita módulo
@Component({
  selector: 'app-genre-tag',
  standalone: true,      // ← ya no necesita módulo
  imports: [],           // ← importa lo que necesita directamente
  template: \`<span>{{ genre }}</span>\`
})
export class GenreTagComponent {
  @Input() genre!: string;
}

// El consumidor importa el COMPONENTE directamente
@Component({
  selector: 'app-movies-page',
  standalone: true,
  imports: [GenreTagComponent],  // ← directo, sin módulo intermediario
})
export class MoviesPageComponent {}`;
}
