import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatChipsModule } from '@angular/material/chips';
import { MatBadgeModule } from '@angular/material/badge';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDividerModule } from '@angular/material/divider';
import { MatIconModule } from '@angular/material/icon';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTabsModule } from '@angular/material/tabs';

@Component({
  selector: 'app-material-page',
  standalone: true,
  imports: [
    FormsModule, RouterModule,
    MatCardModule, MatButtonModule, MatFormFieldModule, MatInputModule,
    MatChipsModule, MatBadgeModule, MatProgressSpinnerModule, MatProgressBarModule,
    MatTooltipModule, MatDividerModule, MatIconModule, MatSlideToggleModule, MatTabsModule,
  ],
  templateUrl: './material-page.component.html',
  styleUrl: './material-page.component.css',
})
export class MaterialPageComponent {
  private snackBar = inject(MatSnackBar);

  inputValor = '';
  toggleActivo = false;
  progreso = 65;

  importCode = `// En el componente standalone — importar directo:
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';

@Component({
  standalone: true,
  imports: [MatCardModule, MatButtonModule],
  template: \`
    <mat-card>
      <mat-card-content>Contenido</mat-card-content>
      <mat-card-actions>
        <button mat-raised-button color="primary">Acción</button>
      </mat-card-actions>
    </mat-card>
  \`
})`;

  mostrarSnackbar() {
    this.snackBar.open('¡Acción ejecutada correctamente!', 'Cerrar', { duration: 3000 });
  }

  mostrarSnackbarError() {
    this.snackBar.open('Error al procesar la solicitud', 'Reintentar', { duration: 4000 });
  }
}
