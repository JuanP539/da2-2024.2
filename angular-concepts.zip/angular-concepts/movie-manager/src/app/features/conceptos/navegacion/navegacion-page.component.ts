import { Component, signal, inject } from '@angular/core';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-navegacion-page',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './navegacion-page.component.html',
  styleUrl: './navegacion-page.component.css',
})
export class NavegacionPageComponent {
  private router = inject(Router);
  activeTab = signal<string>('routing');
  setTab(tab: string) { this.activeTab.set(tab); }

  navegarPorCodigo() {
    this.router.navigate(['/conceptos/servicios']);
  }

  routesCode = `// app.routes.ts
export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'movies', component: MoviesPageComponent },
  { path: 'login', component: LoginComponent },

  // Lazy loading: el componente se carga solo cuando se navega
  {
    path: 'conceptos/componentes',
    loadComponent: () =>
      import('./conceptos/componentes/componentes-page.component')
        .then(m => m.ComponentesPageComponent),
  },

  { path: '**', component: NotFoundComponent },  // 404 — wildcard
];`;

  guardCode = `// auth.guard.ts
export const authGuard: CanActivateFn = () => {
  const authService = inject(AuthService);
  const router = inject(Router);

  if (authService.isLogged()) {
    return true;          // ✅ permite el acceso
  }
  router.navigate(['/login']);
  return false;           // ❌ bloquea y redirige al login
};

// En las rutas — proteger una ruta:
{
  path: 'movies',
  component: MoviesPageComponent,
  canActivate: [authGuard]    // <- guard aplicado
}`;
}
