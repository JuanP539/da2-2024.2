import { Component, signal, inject } from '@angular/core';
import {
  UpperCasePipe, LowerCasePipe, TitleCasePipe,
  DatePipe, CurrencyPipe, DecimalPipe, PercentPipe,
  JsonPipe, SlicePipe, AsyncPipe,
} from '@angular/common';
import { RouterModule } from '@angular/router';
import { Observable, of, delay } from 'rxjs';
import { TruncatePipe } from './truncate.pipe';
import { MovieService } from '../../movies/services/movie.service';
import { Movie } from '../../movies/models/movie.model';

@Component({
  selector: 'app-pipes-page',
  standalone: true,
  imports: [
    RouterModule,
    UpperCasePipe, LowerCasePipe, TitleCasePipe,
    DatePipe, CurrencyPipe, DecimalPipe, PercentPipe,
    JsonPipe, SlicePipe, AsyncPipe,
    TruncatePipe,
  ],
  templateUrl: './pipes-page.component.html',
  styleUrl: './pipes-page.component.css',
})
export class PipesPageComponent {
  private movieService = inject(MovieService);

  activeTab = signal<string>('texto');
  setTab(tab: string) { this.activeTab.set(tab); }

  peliculas: Movie[] = this.movieService.getMockMovies();
  peliculaDemo: Movie = this.peliculas[0];

  sliceEnd = signal<number>(3);
  truncateLimit = signal<number>(80);

  peliculas$: Observable<Movie[]> = of(this.peliculas).pipe(delay(2000));

  recargarAsync() {
    this.peliculas$ = of(this.peliculas).pipe(delay(2000));
  }

  increaseSlice() { if (this.sliceEnd() < this.peliculas.length) this.sliceEnd.set(this.sliceEnd() + 1); }
  decreaseSlice() { if (this.sliceEnd() > 1) this.sliceEnd.set(this.sliceEnd() - 1); }
  increaseTruncate() { if (this.truncateLimit() < 200) this.truncateLimit.set(this.truncateLimit() + 20); }
  decreaseTruncate() { if (this.truncateLimit() > 20) this.truncateLimit.set(this.truncateLimit() - 20); }

  // Code snippets almacenados como strings para evitar que Angular los evalúe en el template
  readonly exprRaw = '{{ title }}';
  readonly exprUpper = '{{ title | uppercase }}';
  readonly exprLower = '{{ title | lowercase }}';
  readonly exprTitle = '{{ title | titlecase }}';
  readonly codeChained = `{{ title | uppercase | slice:0:7 }}`;
  readonly codeTruncateUsage = '{{ texto | truncate:80 }}';

  readonly codeAsync = `// peliculas$ es un Observable<Movie[]> con delay(2000)
@if (peliculas$ | async; as movies) {
  @for (p of movies; track p.id) {
    <li>{{ p.title }}</li>
  }
} @else {
  <div class="spinner-border"></div>
}`;

  readonly codeManualSub = `private sub!: Subscription;

ngOnInit() {
  this.sub = this.peliculas$.subscribe(movies => {
    this.movies = movies;
  });
}

ngOnDestroy() {
  this.sub.unsubscribe(); // Hay que recordarlo siempre
}`;

  readonly codeTruncatePipe = `@Pipe({ name: 'truncate', standalone: true })
export class TruncatePipe implements PipeTransform {
  transform(value: string, limit = 100, trail = '...'): string {
    if (!value) return '';
    return value.length > limit
      ? value.substring(0, limit) + trail
      : value;
  }
}`;

  get codeTruncateDynamic(): string {
    return `{{ overview | truncate:${this.truncateLimit()} }}`;
  }
}
