import { Component, signal, inject } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MovieService } from '../../movies/services/movie.service';
import { AuthService } from '../../auth/services/auth.service';

@Component({
  selector: 'app-servicios-page',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './servicios-page.component.html',
  styleUrl: './servicios-page.component.css',
})
export class ServiciosPageComponent {
  // Inyección con inject() — forma moderna (Angular 14+)
  private movieService = inject(MovieService);
  authService = inject(AuthService);

  activeTab = signal<string>('que-es');
  setTab(tab: string) { this.activeTab.set(tab); }

  peliculas = this.movieService.getMockMovies();

  serviceCode = `@Injectable({ providedIn: 'root' })  // singleton global
export class MovieService {
  movies = signal<Movie[]>([]);
  isLoading = signal(false);

  constructor(private http: HttpClient) {}

  loadPopularMovies() {
    this.isLoading.set(true);
    this.http.get('/api/movies').subscribe(data => {
      this.movies.set(data);
      this.isLoading.set(false);
    });
  }
}`;

  diCode = `// Forma 1: inject() — moderna (Angular 14+)
export class MoviesPageComponent {
  private movieService = inject(MovieService);
}

// Forma 2: constructor — clásica
export class MoviesPageComponent {
  constructor(private movieService: MovieService) {}
}`;

  singletonCode = `// ComponenteA — obtiene la instancia del servicio
private movieService = inject(MovieService);
// → Angular crea MovieService#1

// ComponenteB — en otra parte de la app
private movieService = inject(MovieService);
// → Angular entrega la MISMA MovieService#1

// Resultado: ambos ven los mismos datos.
// Si ComponenteA llama loadMovies(), ComponenteB ve el resultado.`;
}
