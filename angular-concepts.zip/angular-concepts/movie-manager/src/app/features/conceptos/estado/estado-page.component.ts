import { Component, signal, inject } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AuthService } from '../../auth/services/auth.service';

@Component({
  selector: 'app-estado-page',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './estado-page.component.html',
  styleUrl: './estado-page.component.css',
})
export class EstadoPageComponent {
  authService = inject(AuthService);
  activeTab = signal<string>('problema');
  setTab(tab: string) { this.activeTab.set(tab); }

  problemCode = `// AuthService ANTES (sin reactividad)
export class AuthService {
  private isLogged = false;     // booleano simple

  login() { this.isLogged = true; }
  isUserLogged() { return this.isLogged; }
}

// NavbarComponent — el problema:
export class NavbarComponent {
  // Angular tiene que llamar isUserLogged() en CADA ciclo
  // de detección de cambios para saber si el estado cambió.
  // No hay notificación automática.
  get estaLogueado() {
    return this.authService.isUserLogged();
  }
}`;

  solutionCode = `// AuthService AHORA (con signal)
export class AuthService {
  isLogged = signal(false);     // signal reactivo

  login() { this.isLogged.set(true); }
  logout() { this.isLogged.set(false); }
}

// NavbarComponent — la solución:
export class NavbarComponent {
  authService = inject(AuthService);
  // Template: @if (authService.isLogged()) { ... }
  //
  // Angular sabe que el template depende de isLogged().
  // Cuando isLogged cambia, solo el Navbar se re-renderiza.
  // Sin polling. Sin detectChanges(). Sin boilerplate.
}`;

  simularLogin() { this.authService.login('user', '1234'); }
  simularLogout() { this.authService.logout(); }
}
