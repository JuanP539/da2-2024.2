import { Component, signal, inject } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SlicePipe } from '@angular/common';
import { MovieService } from '../../movies/services/movie.service';
import { Movie } from '../../movies/models/movie.model';
import { LoadingService } from './loading.service';
import { AuthService } from '../../auth/services/auth.service';

@Component({
  selector: 'app-interceptores-page',
  standalone: true,
  imports: [RouterModule, SlicePipe],
  templateUrl: './interceptores-page.component.html',
  styleUrl: './interceptores-page.component.css',
})
export class InterceptoresPageComponent {
  private movieService = inject(MovieService);
  private authService = inject(AuthService);
  loadingService = inject(LoadingService);

  activeTab = signal<string>('que-es');
  setTab(tab: string) { this.activeTab.set(tab); }

  isLogged = this.authService.isLogged;

  resultados = signal<Movie[]>([]);
  searched = signal(false);

  buscarPeliculas() {
    this.searched.set(false);
    this.resultados.set([]);
    this.movieService.searchMovies('batman').subscribe(movies => {
      this.resultados.set(movies.slice(0, 4));
      this.searched.set(true);
    });
  }

  login() { this.authService.login('user', '1234'); }
  logout() { this.authService.logout(); }

  // Code snippets
  readonly codeNextMal = `loading.isLoading.set(true);
return next(req);
// ❌ El interceptor termina acá.
// No hay código que se ejecute "a la vuelta".`;

  readonly codeNextBien = `loading.isLoading.set(true);
return next(req).pipe(
  finalize(() => loading.isLoading.set(false))
);
// ✅ finalize queda "registrado" dentro del Observable.
// Cuando la respuesta llega (o falla), el Observable lo ejecuta.`;
  readonly codeRegistro = `import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { loadingInterceptor } from './interceptores/loading.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    provideHttpClient(
      withInterceptors([loadingInterceptor])
    ),
  ],
};`;

  readonly codeAuthInterceptor = `export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);

  if (!authService.isLogged()) return next(req); // Sin login: pasa sin tocar

  const token = localStorage.getItem('token') ?? '';
  const authReq = req.clone({
    setHeaders: { Authorization: \`Bearer \${token}\` },
  });
  return next(authReq); // Envía la request modificada
};`;

  readonly codeLoadingInterceptor = `export const loadingInterceptor: HttpInterceptorFn =
  (req, next) => {
    const loading = inject(LoadingService);

    loading.isLoading.set(true);

    return next(req).pipe(
      finalize(() => loading.isLoading.set(false))
    );
  };`;

  readonly codeLoadingService = `@Injectable({ providedIn: 'root' })
export class LoadingService {
  isLoading = signal(false);
}`;

  readonly codeLoadingUso = `loadingService = inject(LoadingService);

// En el template:
@if (loadingService.isLoading()) {
  <spinner />
}`;

  readonly codeClase = `@Injectable()
export class AuthInterceptor
  implements HttpInterceptor {

  constructor(
    private authService: AuthService
  ) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {

    if (!this.authService.isLogged())
      return next.handle(req);

    const authReq = req.clone({
      setHeaders: {
        Authorization: \`Bearer \${token}\`
      }
    });
    return next.handle(authReq);
  }
}`;

  readonly codeRegistroClase = `provideHttpClient(
  withInterceptorsFromDi()
),
{
  provide: HTTP_INTERCEPTORS,
  useClass: AuthInterceptor,
  multi: true
}`;

  readonly codeFuncion = `export const authInterceptor:
  HttpInterceptorFn = (req, next) => {

  const authService = inject(AuthService);

  if (!authService.isLogged())
    return next(req);

  const authReq = req.clone({
    setHeaders: {
      Authorization: \`Bearer \${token}\`
    }
  });
  return next(authReq);
};`;

  readonly codeRegistroFuncion = `provideHttpClient(
  withInterceptors([authInterceptor])
)`;
}
