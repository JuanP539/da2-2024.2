import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from '../../auth/services/auth.service';

// Interceptor de ejemplo — no registrado globalmente en app.config.ts
// para no interferir con la API de TMDb que usa su propia autenticación.
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);

  if (!authService.isLogged()) return next(req);

  const token = localStorage.getItem('token') ?? '';
  const authReq = req.clone({
    setHeaders: { Authorization: `Bearer ${token}` },
  });
  return next(authReq);
};
