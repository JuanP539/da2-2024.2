import { Component, Input, Output, EventEmitter, OnInit, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import { UpperCasePipe } from '@angular/common';
import { Movie } from '../../../../features/movies/models/movie.model';

@Component({
  selector: 'app-movie-card-demo',
  standalone: true,
  imports: [UpperCasePipe],
  templateUrl: './movie-card-demo.component.html',
  styleUrl: './movie-card-demo.component.css',
})
export class MovieCardDemoComponent implements OnInit, OnChanges, OnDestroy {
  // @Input: el padre le pasa datos al hijo
  @Input({ required: true }) movie!: Movie;
  @Input() destacada: boolean = false;

  // @Output: el hijo emite eventos hacia el padre
  @Output() seleccionada = new EventEmitter<Movie>();
  @Output() agregadaFavoritos = new EventEmitter<Movie>();

  esFavorita = false;

  // Lifecycle: se ejecuta una vez al crear el componente
  ngOnInit() {
    console.log(`[ngOnInit] MovieCardDemo "${this.movie.title}" creado`);
  }

  // Lifecycle: se ejecuta cada vez que cambia un @Input
  ngOnChanges(changes: SimpleChanges) {
    if (changes['movie']) {
      console.log(`[ngOnChanges] Película cambió a: "${this.movie.title}"`);
    }
  }

  // Lifecycle: se ejecuta al destruir el componente
  ngOnDestroy() {
    console.log(`[ngOnDestroy] MovieCardDemo "${this.movie.title}" destruido`);
  }

  seleccionar() {
    this.seleccionada.emit(this.movie);
  }

  toggleFavorito() {
    this.esFavorita = !this.esFavorita;
    if (this.esFavorita) this.agregadaFavoritos.emit(this.movie);
  }
}
