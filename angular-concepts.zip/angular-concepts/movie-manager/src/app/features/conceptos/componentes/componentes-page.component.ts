import { Component, signal, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MovieCardDemoComponent } from './movie-card-demo/movie-card-demo.component';
import { MovieService } from '../../movies/services/movie.service';
import { Movie } from '../../movies/models/movie.model';

@Component({
  selector: 'app-componentes-page',
  standalone: true,
  imports: [FormsModule, RouterModule, MovieCardDemoComponent],
  templateUrl: './componentes-page.component.html',
  styleUrl: './componentes-page.component.css',
})
export class ComponentesPageComponent {
  private movieService = inject(MovieService);

  activeTab = signal<string>('io');

  // Demo @Input / @Output
  peliculaActual: Movie = this.movieService.getMockMovies()[0];
  peliculaSeleccionada: Movie | null = null;
  favoritos: Movie[] = [];
  mostrarCard = true;

  // Demo two-way binding
  tituloEditado = 'Mi película favorita';

  setTab(tab: string) { this.activeTab.set(tab); }

  onSeleccionada(movie: Movie) { this.peliculaSeleccionada = movie; }

  onAgregadaFavoritos(movie: Movie) {
    if (!this.favoritos.find(f => f.id === movie.id)) {
      this.favoritos = [...this.favoritos, movie];
    }
  }

  cambiarPelicula() {
    const mocks = this.movieService.getMockMovies();
    const idx = mocks.findIndex(m => m.id === this.peliculaActual.id);
    this.peliculaActual = mocks[(idx + 1) % mocks.length];
  }

  toggleCard() { this.mostrarCard = !this.mostrarCard; }
}
