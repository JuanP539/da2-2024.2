import { Component, EventEmitter, inject, OnDestroy, OnInit, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Movie } from '../../models/movie.model';
import { MovieService } from '../../services/movie.service';
import { MovieCardComponent } from '../movies-card/movies-card.component';

@Component({
  selector: 'app-movie-list',
  imports: [CommonModule, MovieCardComponent],
  templateUrl: './movies-list.component.html',
  styleUrls: ['./movies-list.component.css'],
})
export class MovieListComponent implements OnInit, OnDestroy {
  private movieService = inject(MovieService);

  movies = this.movieService.movies;
  isLoading = this.movieService.isLoading;
  error = this.movieService.error;

  @Output() movieSelected = new EventEmitter<Movie>();

  ngOnInit() {
    console.log('[OnInit] MovieListComponent creado');
    this.movieService.loadPopularMovies();
  }

  ngOnDestroy() {
    console.log('[OnDestroy] MovieListComponent eliminado');
  }

  onSelect(movie: Movie) {
    console.log(`[SelectMovie] Recibida en MovieListComponent: ${movie.title}`);
    this.movieSelected.emit(movie);
  }
}
