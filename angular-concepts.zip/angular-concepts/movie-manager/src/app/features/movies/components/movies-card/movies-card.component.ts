import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { Movie } from '../../models/movie.model';

@Component({
  selector: 'app-movie-card',
  imports: [],
  templateUrl: './movies-card.component.html',
  styleUrl: './movies-card.component.css'
})
export class MovieCardComponent implements OnInit, OnChanges, OnDestroy {
  @Input({ required: true }) movie!: Movie;
  @Output() selected = new EventEmitter<Movie>();

  ngOnInit() {
    console.log(`[OnInit] MovieCard for "${this.movie.title}" creado`);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['movie']) {
      console.log(`[OnChanges] MovieCard for "${this.movie.title}" actualizado`);
    }
  }

  ngOnDestroy() {
    console.log(`[OnDestroy] MovieCard for "${this.movie.title}" eliminado`);
  }

  selectMovie() {
    console.log(`[SelectMovie] Seleccionada: ${this.movie.title}`);
    this.selected.emit(this.movie);
  }
}
