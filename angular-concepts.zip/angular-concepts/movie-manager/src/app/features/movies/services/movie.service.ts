import { Injectable, signal } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Movie } from '../models/movie.model';

@Injectable({ providedIn: 'root' })
export class MovieService {
  private apiUrl = 'https://api.themoviedb.org/3';
  private apiKey = '36eb10aa56ea823b1b3c7370a05aeb09';
  private imageBaseUrl = 'https://image.tmdb.org/t/p/w500';

  private readonly MOCK_MOVIES: Movie[] = [
    { id: 1, title: 'Inception', overview: 'Un ladrón que roba secretos a través del sueño del objetivo.', original_language: 'en', poster_path: 'assets/no-poster.png', release_date: '2010-07-16', vote_average: 8.8 },
    { id: 2, title: 'The Dark Knight', overview: 'Batman enfrenta al Joker en Gotham City en una batalla épica.', original_language: 'en', poster_path: 'assets/no-poster.png', release_date: '2008-07-18', vote_average: 9.0 },
    { id: 3, title: 'Interstellar', overview: 'Un equipo de exploradores viaja a través de un agujero de gusano en busca de un nuevo hogar.', original_language: 'en', poster_path: 'assets/no-poster.png', release_date: '2014-11-07', vote_average: 8.6 },
    { id: 4, title: 'El secreto de sus ojos', overview: 'Un oficial judicial reconstruye un crimen que marcó su vida hace 25 años.', original_language: 'es', poster_path: 'assets/no-poster.png', release_date: '2009-08-13', vote_average: 8.1 },
    { id: 5, title: 'Nueve Reinas', overview: 'Dos estafadores se unen para ejecutar el engaño de sus vidas en Buenos Aires.', original_language: 'es', poster_path: 'assets/no-poster.png', release_date: '2000-09-08', vote_average: 8.0 },
    { id: 6, title: 'Amélie', overview: 'Una joven parisina tímida decide cambiar la vida de quienes la rodean.', original_language: 'fr', poster_path: 'assets/no-poster.png', release_date: '2001-04-25', vote_average: 8.3 },
  ];

  movies = signal<Movie[]>([]);
  isLoading = signal(false);
  error = signal<string | null>(null);

  constructor(private http: HttpClient) {}

  loadPopularMovies(page: number = 1) {
    this.isLoading.set(true);
    this.error.set(null);

    const params = new HttpParams()
      .set('api_key', this.apiKey)
      .set('language', 'en-US')
      .set('page', page.toString());

    this.http
      .get<{ results: Movie[] }>(`${this.apiUrl}/movie/popular`, { params })
      .subscribe({
        next: (response) => {
          this.movies.set(response.results.map(m => ({
            ...m,
            poster_path: m.poster_path ? `${this.imageBaseUrl}${m.poster_path}` : 'assets/no-poster.png',
          })));
          this.isLoading.set(false);
        },
        error: () => {
          this.movies.set(this.MOCK_MOVIES);
          this.isLoading.set(false);
        },
      });
  }

  searchMovies(query: string): Observable<Movie[]> {
    if (!query.trim()) return of([]);

    const params = new HttpParams()
      .set('api_key', this.apiKey)
      .set('query', query)
      .set('language', 'en-US');

    return this.http
      .get<{ results: Movie[] }>(`${this.apiUrl}/search/movie`, { params })
      .pipe(
        map(r => r.results.map(m => ({
          ...m,
          poster_path: m.poster_path ? `${this.imageBaseUrl}${m.poster_path}` : 'assets/no-poster.png',
        }))),
        catchError(() => of(
          this.MOCK_MOVIES.filter(m => m.title.toLowerCase().includes(query.toLowerCase()))
        ))
      );
  }

  getMockMovies(): Movie[] {
    return this.MOCK_MOVIES;
  }
}
