import { Component } from '@angular/core';
import { Movie } from '../../models/movie.model';
import { MovieListComponent } from '../../components/movies-list/movies-list.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-movies-page',
  imports: [CommonModule, MovieListComponent],
  templateUrl: './movies-page.component.html',
  styleUrl: './movies-page.component.css'
})
export class MoviesPageComponent {
  showList = true;
  selectedMovie?: Movie = undefined;

  onMovieSelected(movie: Movie) {
    console.log(`[SelectMovie] Recibida en MoviesPageComponent: ${movie.title}`);
    this.selectedMovie = movie;
  }

  toggleList() {
    this.showList = !this.showList;
  }
}
