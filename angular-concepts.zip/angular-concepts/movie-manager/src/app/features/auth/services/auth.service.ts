import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {
  // ============================================================
  // VERSIÓN ANTIGUA (sin reactividad):
  // private isLoggedBool = false;
  // public isUserLogged(): boolean { return this.isLoggedBool; }
  //
  // Problema: el Navbar no detecta el cambio automáticamente.
  // Hay que consultar el valor en cada ciclo de detección.
  // ============================================================

  // VERSIÓN CON SIGNAL: el cambio se propaga automáticamente
  isLogged = signal(false);

  public login(email: string, password: string): boolean {
    if (email === 'user' && password === '1234') {
      this.isLogged.set(true);
      localStorage.setItem('token', 'token-back');
      return true;
    }
    alert('Credenciales inválidas');
    return false;
  }

  public logout(): void {
    this.isLogged.set(false);
    localStorage.removeItem('token');
  }

  public isUserLogged(): boolean {
    return this.isLogged();
  }
}
