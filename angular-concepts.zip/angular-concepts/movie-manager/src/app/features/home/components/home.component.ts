import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

interface ConceptCard {
  titulo: string;
  descripcion: string;
  ruta: string;
  icono: string;
  color: string;
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterModule, MatCardModule, MatButtonModule, MatIconModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent {
  conceptos: ConceptCard[] = [
    { titulo: 'Componentes', descripcion: '@Input, @Output, two-way binding y lifecycle hooks.', ruta: '/conceptos/componentes', icono: 'widgets', color: '#3f51b5' },
    { titulo: 'Módulos vs Standalone', descripcion: 'NgModule clásico vs componentes standalone de Angular 19.', ruta: '/conceptos/modulos', icono: 'view_module', color: '#9c27b0' },
    { titulo: 'Directivas', descripcion: 'Built-in (ngFor, ngSwitch) y directivas personalizadas de atributo y estructurales.', ruta: '/conceptos/directivas', icono: 'tune', color: '#e91e63' },
    { titulo: 'Servicios', descripcion: 'Inyección de dependencias, providedIn root y comunicación entre componentes.', ruta: '/conceptos/servicios', icono: 'miscellaneous_services', color: '#ff5722' },
    { titulo: 'Navegación', descripcion: 'Routing, lazy loading y guardas de acceso.', ruta: '/conceptos/navegacion', icono: 'route', color: '#009688' },
    { titulo: 'Signals vs Observables', descripcion: 'Cuándo usar cada uno y cómo se complementan en una búsqueda real.', ruta: '/conceptos/signals-observables', icono: 'compare_arrows', color: '#ff9800' },
    { titulo: 'Estado', descripcion: 'Estado reactivo global con signals: el problema del booleano y la solución.', ruta: '/conceptos/estado', icono: 'memory', color: '#607d8b' },
    { titulo: 'Angular Material', descripcion: 'Biblioteca de componentes UI que siguen Material Design de Google.', ruta: '/conceptos/material', icono: 'palette', color: '#795548' },
    { titulo: 'Pipes', descripcion: 'Transformá datos en el template con | uppercase, | date, | async y pipes personalizados.', ruta: '/conceptos/pipes', icono: 'transform', color: '#00897b' },
    { titulo: 'Interceptors', descripcion: 'Middleware HTTP para agregar auth headers, spinner de carga y manejo global de errores.', ruta: '/conceptos/interceptores', icono: 'filter_alt', color: '#1565c0' },
  ];
}
